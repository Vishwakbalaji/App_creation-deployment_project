
# Data Quality & Exploratory Analysis Accelerator

The app detects and reports data quality metrics. It provides facility to conduct exploratory data analysis in an adhoc way providing results via interactive components and visualizations.

## Development Guide

### Clone Repo

```bash
  git clone https://<your-git-username>@github.com/<your-git-username>/data_quality_accelerator.git
```

### Installation
Create virtual environment \
Install dependencies listed at requirements.txt in the venv \
Activate the venv \

### Run
```bash 
streamlit run src\Home.py
```

### Coding Standards
* Visual Studio code is the recommended IDE as settings.json ships with the repo. Formatting, linting, sorted imports are standardized in the settings.json, simply installing the dependencies and using VS Code will ensure the standards. 
* If one has strong preference towards any other IDE, please follow these standards :
    - (1) format the code using Black formatter     
    - (2) Use isort to sort the imports 
    - (3) Use pylint and flake8 to check for linting warnings & errors and correct the maximum possible among them.