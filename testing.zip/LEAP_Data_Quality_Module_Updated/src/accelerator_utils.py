"""
Utility functions to compute data quality metrics and eda methods.
Except for the streamlit cache decorator the functions do not use streamlit related components.
"""
import datetime as dt
import itertools
import os
from datetime import datetime
from typing import Dict, List

import numpy as np
import pandas as pd
import requests
import streamlit as st
from dateutil.relativedelta import relativedelta
from loguru import logger
from pandas.api.types import is_numeric_dtype
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler


@st.cache_data
def get_data_df(dataset_path: str):
    """fetch data from parameterized path input and loads into pandas frame.
    Currently reads only csv files.
    Reads the entire data into pandas, hence this method is to be used with caution.
    """
    try:
        if not dataset_path:
            logger.error(f"Did not receive a valid dataset path. dataset path = {dataset_path}")
            return None
        if not dataset_path.endswith("csv"):
            logger.warning(
                f"Received a non-csv filepath to read. only csv files are supported. "
                f"dataset path = {dataset_path}"
            )
            return None
        df = pd.read_csv(dataset_path)
        # convert possible date columns from generic object type to datetime
        df = df.apply(
            lambda col: pd.to_datetime(col, errors="ignore") if col.dtypes == object else col,
            axis=0,
        )
        return df
    except FileNotFoundError as fex:
        logger.error(f"{fex}")
        return None
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def get_dataset_summary(dataset_path: str) -> pd.DataFrame:
    """
    Provides high level summary of file like its size, last modified time, #rows, #columns
    """
    try:
        data_df = get_data_df(dataset_path)

        if data_df is None:
            logger.error(f"could not get data for the dataset path = {dataset_path}...")
            return None

        file_stats = os.stat(dataset_path)
        file_size_bytes = os.path.getsize(dataset_path)

        if dataset_path.endswith(".csv"):
            ds_name = dataset_path.split("/")[-1].split(".csv")[0]
        else:
            ds_name = dataset_path.split("/")[-1]

        return pd.DataFrame(
            data=[
                {"Metric": "Dataset name", "Value": ds_name},
                {"Metric": "Number of rows", "Value": data_df.shape[0]},
                {"Metric": "Number of columns", "Value": data_df.shape[1]},
                {
                    "Metric": "File size",
                    "Value": f"{file_size_bytes/(1<<20):,.0f} MB / {file_size_bytes/(1<<30):,.0f} GB",
                },
                {
                    "Metric": "Last Modified time",
                    "Value": dt.datetime.fromtimestamp(file_stats.st_mtime),
                },
            ]
        )
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def get_column_summary(data_df: pd.DataFrame, col: str) -> Dict:
    """
    Provides data quality metrics of a column like the columns datatype,
    #null values, #unique values, proportion of unique values wrt total rows,
    #negative values, #zeros
    """
    try:
        data_type = str(data_df[col].dtype)
        n_nulls = data_df[col].isna().sum()
        n_unique = data_df[col].nunique()

        n_negatives = (
            data_df[data_df[col] < 0].shape[0]
            if is_numeric_dtype(data_df[col])
            else "Not Applicable"
        )

        n_zeros = (
            data_df[data_df[col] == 0].shape[0]
            if is_numeric_dtype(data_df[col])
            else "Not Applicable"
        )
        return {
            "Column": col,
            "Data Type": data_type,
            "Number of null values": n_nulls,
            "Number of unique values": n_unique,
            "Proportion of unique Values w.r.t all rows": n_unique / data_df.shape[0],
            "Number of rows with negative values": n_negatives,
            "Number of rows with zeros": n_zeros,
        }
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def get_duplicate_summary(data_df: pd.DataFrame) -> Dict:
    """
    Provides analysis on duplicates.
    detects #duplicate rows, #duplicate columns.
    duplicate columns are based on column values.
    detects and return count and actual duplicated pairs of columns.
    """
    try:
        nrows, ncols = data_df.shape
        duplicate_rows = data_df[data_df.duplicated()]

        dup_col_pairs = []
        only_duplicate_cols = []
        for col1, col2 in list(itertools.combinations(data_df.columns, 2)):
            if data_df[col1].equals(data_df[col2]):
                dup_col_pairs.append((col1, col2))
                only_duplicate_cols.append(col2)

        return {
            "Number of rows": nrows,
            "Number of duplicate rows": duplicate_rows.shape[0],
            "Number of columns": ncols,
            "Number of duplicate columns": len(only_duplicate_cols),
            "Duplicate columns": only_duplicate_cols,
            "Duplicate column pairs": dup_col_pairs,
        }
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def get_data_completeness(inp_df: pd.DataFrame) -> pd.DataFrame:
    """
    Provides insights on completeness of data.
    returns the number rows that have 10% (20%,..upto 100%) of columns missing.
    """
    try:
        data_df = inp_df.copy(deep=True)
        n_cols = data_df.shape[1]
        data_df["n_cols_missing"] = n_cols - data_df.count(axis=1)
        data_df["perc_cols_missing"] = data_df["n_cols_missing"] / n_cols
        data_df["quantile_cols_missing"] = pd.cut(
            data_df["perc_cols_missing"] * 100,
            bins=[0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100],
            labels=[
                "<10%",
                "10%-20%",
                "20%-30%",
                "30%-40%",
                "40%-50%",
                "50%-60%",
                "60%-70%",
                "70%-80%",
                "80%-90%",
                "90%-100%",
            ],
            include_lowest=False,  # not including 0 as it means no missing
            right=True,  # intervals to include upper bound
        )
        result_df = pd.DataFrame(data_df["quantile_cols_missing"].value_counts().reset_index())
        result_df.columns = ["% cols missing", "number of rows"]
        result_df.sort_values("% cols missing", ascending=True, inplace=True)
        result_df["% of total rows"] = round(
            (result_df["number of rows"] / result_df["number of rows"].sum()) * 100, 2
        )
        result_df["% of total rows"].fillna(0, inplace=True)
        return result_df
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def get_missing_correlations(inp_df: pd.DataFrame) -> pd.DataFrame:
    """
    This method computes correlations of missing values between pairs of columns.
    1 is highly correlated and -1 is highly inversly correlated. 0 is no correlation.
    The correlation values are then scaled to a range of 0 to 100.
    Scaled values are converted to integers for readability/use in plots.
    """
    try:
        data_df = inp_df.isnull().astype(int)
        result = []
        seen_cols = set()
        for col1, col2 in list(itertools.combinations(data_df.columns, 2)):
            corr = np.corrcoef(data_df[col1], data_df[col2])[0][1]
            result.append([col1, col2, corr])
            result.append([col2, col1, corr])
            if col1 not in seen_cols:
                result.append([col1, col1, 1])
                seen_cols.add(col1)
        df_corr = pd.DataFrame(result, columns=["col1", "col2", "corr"])
        df_corr["corr"].fillna(0, inplace=True)
        scaler = MinMaxScaler(feature_range=(0, 100))
        df_corr["corr_scaled"] = scaler.fit_transform(df_corr["corr"].values.reshape(-1, 1))
        df_corr["corr_scaled"] = df_corr["corr_scaled"].astype(int)
        return df_corr
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def get_distribution_quartiles(data_df: pd.DataFrame, col: str) -> pd.Series:
    """
    Returns the distribution summary of column that shows mean, std.dev and quartile values.
    """
    try:
        return data_df[col].describe()
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def get_frequency_counts(data_df: pd.DataFrame, col: str) -> pd.Series:
    """
    Returns frequency distribution of categories of categorical column.
    """
    try:
        data_df[col] = data_df[col].str.strip()
        return data_df[col].value_counts()
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def get_histogram(inp_df: pd.DataFrame, col: str, nbins="auto") -> Dict:
    """
    Generate histogram for given data using the default auto method of binning.
    Reference: https://numpy.org/doc/stable/reference/generated/numpy.histogram_bin_edges.html#numpy.histogram_bin_edges
    Returns a dictionary of edges and counts.
    values in edges mean corresponding frequency counts are lesser than the edge value.
    All but the last (righthand-most) bin is half-open. In other words, if bins is: [1, 2, 3, 4]
    then the first bin is [1, 2) (including 1, but excluding 2) 2) and the second [2, 3).
    The last bin, however, is [3, 4], which includes 4.
    """
    try:
        logger.info(f"\n\n inside get histogram ... input shape = {inp_df.shape}")
        data_df = inp_df[[col]]
        if not is_numeric_dtype(data_df[col]):
            logger.warning("histogram cannot be computed for non-numeric column")
            return None
        data_df = data_df[data_df[col].notnull()]
        hist, edges = np.histogram(data_df[col].values, bins=nbins, density=False)
        return {"edges": edges[1:].tolist(), "frequencies": hist.tolist()}
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def detect_outliers(inp_df: pd.DataFrame, col: str, method="robust_z_score") -> Dict:
    """
    Detect outliers in univariate setting and returns outlier's indexes and actual values.
    Additionally returns the boundary / value range of outliers, number of unique outliers
    """
    try:
        inp_df_copy = inp_df.copy(deep=True)
        data_df = inp_df_copy[inp_df_copy[col].notnull()]
        data = data_df[col].values
        if method == "robust_z_score":
            # standard z score uses mean which by itself is influenced by outliers
            # using median instead makes it robust.
            # Reference: https://medium.com/@joaopedroferrazrodrigues/outliers-make-us-go-mad-univariate-outlier-detection-b3a72f1ea8c7
            # Reference: https://www.statology.org/modified-z-score/
            THRESHOLD = 3.5  # 3.762
            overall_med = np.median(data)
            mad = np.median([np.abs(val - overall_med) for val in data])
            modified_z_scores = [
                0.6745 * (val - overall_med) / mad for val in data
            ]  # instead of 0.7974-
            logger.debug(
                f"overall_med = {overall_med} \n mad= {mad} \n max score = {max(modified_z_scores)}"
            )

            unique_outlier_values = set(
                [
                    data[i]
                    for i in range(len(modified_z_scores))
                    if np.abs(modified_z_scores[i]) > THRESHOLD
                ]
            )
            inp_df_copy["is_outlier"] = inp_df_copy[col].map(
                lambda val: 1 if val in unique_outlier_values else 0
            )
            outlier_indexes = inp_df_copy[inp_df_copy["is_outlier"] == 1].index.tolist()
            outlier_values = inp_df_copy[inp_df_copy["is_outlier"] == 1][col].values.tolist()

            outlier_left_boundary = np.max(
                [val for val in unique_outlier_values if val < overall_med] or [None]
            )
            outlier_right_boundary = np.min(
                [val for val in unique_outlier_values if val > overall_med] or [None]
            )

            return {
                "outlier_indexes": list(outlier_indexes),
                "outlier_values": list(outlier_values),
                "n_outliers": len(outlier_values),
                "n_unique_outliers": len(unique_outlier_values),
                "perc_of_outliers": round((len(outlier_values) / len(data)) * 100, 2),
                "outlier_boundary_left": outlier_left_boundary,
                "outlier_boundary_right": outlier_right_boundary,
                "n_rows": len(data),
                "colname": col,
            }
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def detect_date_frequency(inp_df: pd.DataFrame, col: str) -> str:
    """
    Identify the frequency of a date column.
    The detected frequency is only an approximation.
    function also returns a prevalence score, ie how many periods were available out of the ideal.
    """
    try:
        if str(inp_df[col].dtype) != "datetime64[ns]":
            logger.warning(
                f"Cannot detect date frequency for a non-datetime type column. col type received =  {str(inp_df[col].dtype)}"
            )
            return None
        data_df = inp_df.copy(deep=True)
        data_df["dt_year"] = data_df[col].dt.year
        data_df["dt_quarter"] = data_df[col].dt.quarter
        data_df["dt_month"] = data_df[col].dt.month
        data_df["dt_week"] = data_df[col].dt.week
        data_df["dt_day"] = data_df[col].dt.day
        data_df["dt_hr"] = data_df[col].dt.hour
        data_df["dt_minute"] = data_df[col].dt.minute
        data_df["dt_second"] = data_df[col].dt.second

        # for datasets with less than a yr the ideal number of quarters and months are adjusted
        max_dt = data_df[col].max()
        min_dt = data_df[col].min()
        delta = relativedelta(max_dt, min_dt)
        total_months = (delta.years * 12) + delta.months

        n_quarters = np.ceil(total_months / 4) if total_months < 12 else 4
        n_months = total_months if total_months < 12 else 12
        n_days = (max_dt - min_dt).days
        n_weeks = np.ceil(n_days / 7) if total_months < 12 else 52
        n_days = 31 if n_days > 31 else n_days

        date_freq_ratios = [
            ("quarterly", data_df["dt_quarter"].nunique() / n_quarters),
            ("monthly", data_df["dt_month"].nunique() / n_months),
            ("weekly", data_df["dt_week"].nunique() / n_weeks),
            ("daily", data_df["dt_day"].nunique() / n_days),
            ("hourly", data_df["dt_hr"].nunique() / 60),
            ("minute-level", data_df["dt_minute"].nunique() / 60),
            ("second-level", data_df["dt_second"].nunique() / 60),
        ]
        max_ratio = max([v[1] for v in date_freq_ratios])
        max_freq_idx = max(
            [index for index, item in enumerate(date_freq_ratios) if item[1] == max_ratio]
        )
        predicted_frequency = date_freq_ratios[max_freq_idx][0]

        return predicted_frequency, max_ratio
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def get_missing_dates(inp_df: pd.DataFrame, col: str, freq: str) -> List:
    try:
        if str(inp_df[col].dtype) != "datetime64[ns]":
            logger.warning(
                f"Cannot detect date frequency for a non-datetime type column. col type received = {str(inp_df[col].dtype)}"
            )
            return None
        period_freq_map = {
            "quarterly": "Q",
            "weekly": "W-SUN",
            "monthly": "M",
            "daily": "D",
        }
        ideal_periods = pd.period_range(
            start=inp_df[col].min(), end=inp_df[col].max(), freq=period_freq_map[freq]
        )
        missed_periods = pd.period_range(
            start=inp_df[col].min(), end=inp_df[col].max(), freq=period_freq_map[freq]
        ).difference(inp_df[col].dt.to_period(period_freq_map[freq]).unique())

        # missed_periods = [str(val) for val in missed_periods]
        return missed_periods, ideal_periods
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def get_date_column_univariate_insights(inp_df: pd.DataFrame, col: str) -> Dict:
    """
    provides summary of date column like its frequency, min and max dates, missing dates
    """
    try:
        if str(inp_df[col].dtype) != "datetime64[ns]":
            logger.warning(
                f"Cannot detect date frequency for a non-datetime type column. col type received =  {str(inp_df[col].dtype)}"
            )
            return None
        dt_freq, dt_periods_prevalence = detect_date_frequency(inp_df=inp_df, col=col)
        if dt_freq:
            period_freq_map = {
                "quarterly": "Q",
                "weekly": "W-SUN",
                "monthly": "M",
                "daily": "D",
            }
            dt_freq_counts = inp_df[col].dt.to_period(period_freq_map[dt_freq]).value_counts()
        else:
            # too many data points,, might hang the plots..
            dt_freq_counts = None

        min_dt = inp_df[col].min()
        max_dt = inp_df[col].max()

        missed_periods = get_missing_dates(inp_df=inp_df, col=col, freq=dt_freq)

        return {
            "dt_frequency": dt_freq,
            "dt_periods_prevalence": dt_periods_prevalence,
            "dt_freq_counts": dt_freq_counts[:2000],  # to prevent overload
            "min_dt": min_dt,
            "max_dt": max_dt,
            "missed_periods": missed_periods,
            "n_missing_dates": len(missed_periods),
        }
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def get_categorical_by_categorical_aggregates(
    data_df: pd.DataFrame,
    col1: str,
    col2: str,
    agg_col: str = None,
    agg_func: str = "count",
) -> Dict:
    """
    provides aggregation of groups in col1 and col2
    agg function and the column to be used for aggregation are agg_func and agg_col params
    """
    AGG_FUNCS_MAP = {
        "Average": "mean",
        "Sum": "sum",
        "Median": "median",
        "Maximum": "max",
        "Minimum": "min",
    }
    res_df = None
    try:
        if agg_col:
            res_df = (
                data_df.groupby([col1, col2], dropna=False)
                .agg({agg_col: AGG_FUNCS_MAP[agg_func]})
                .reset_index()
            )
            res_df.columns = [col1, col2, agg_col]
        else:
            res_df = (
                data_df.groupby([col1, col2], dropna=False).size().reset_index(name="frequency")
            )
            res_df[[col1, col2]].fillna("__NA__", inplace=True)
        return res_df
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def get_categorical_by_numeric_aggregates(
    data_df: pd.DataFrame,
    categorical_col: str,
    numeric_col: str,
    agg_funcs: List[str] = ["Average"],
) -> Dict:
    """
    provides aggregation of numeric col across categories of categorical col
    """
    AGG_FUNCS_MAP = {
        "Average": "mean",
        "Sum": "sum",
        "Median": "median",
        "Maximum": "max",
        "Minimum": "min",
    }
    res_df = None
    try:
        py_agg_funcs = [AGG_FUNCS_MAP[val] for val in agg_funcs]
        res_df = data_df.groupby(categorical_col).agg({numeric_col: py_agg_funcs}).reset_index()
        res_df.columns = [categorical_col] + agg_funcs
        return res_df
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def get_date_by_numeric_aggregates(
    inp_df: pd.DataFrame,
    date_col: str,
    numeric_col: str,
    agg_freq: str = None,
    agg_funcs: List[str] = ["Average"],
) -> Dict:
    """
    provides aggregation of numeric col across time units of date col
    agg_freq can be yearly, quarterly, monthly, daily, etc based on which groups are made
    if agg freq is not provided it is detected automatically.
    """
    data_df = inp_df[[date_col, numeric_col]]
    if agg_freq is None:
        agg_freq, _ = detect_date_frequency(data_df, date_col)
        if agg_freq is None:
            logger.error(
                f"Could not detect frequency for date col : {date_col}. cannot proceed for aggregations."
            )
            return None

    period_freq_map = {
        "yearly": "Y",
        "quarterly": "Q",
        "weekly": "W-SUN",
        "monthly": "M",
        "daily": "D",
    }
    data_df["_period"] = data_df[date_col].dt.to_period(period_freq_map[agg_freq])

    AGG_FUNCS_MAP = {
        "Average": "mean",
        "Sum": "sum",
        "Median": "median",
        "Maximum": "max",
        "Minimum": "min",
    }
    res_df = None
    try:
        py_agg_funcs = [AGG_FUNCS_MAP[val] for val in agg_funcs]
        res_df = data_df.groupby("_period").agg({numeric_col: py_agg_funcs}).reset_index()
        res_df.columns = [date_col] + agg_funcs
        res_df[date_col] = res_df[date_col].astype("datetime64[ns]")
        return res_df
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def get_cumulative_percent(
    data_df: pd.DataFrame, categorical_col: str, numeric_col: str, method
) -> pd.DataFrame:
    """
    Returns dataframe with cumulative percent column of numerical and categorical column.
    """
    try:
        if method is not None:
            cum_df = pd.pivot_table(
                data_df, index=[categorical_col], aggfunc={numeric_col: method}
            ).reset_index()
        else:
            cum_df = data_df.copy()

        # sorting the numeric_col from desc to asc
        cum_df.sort_values(by=numeric_col, ascending=False, inplace=True)

        # Calculate cumulative sum and percentage
        total = cum_df[numeric_col].sum()
        cum_df["cumulative_percent"] = round(cum_df[numeric_col].cumsum() / total * 100, 2)
        return cum_df
    except Exception as ex:
        logger.error(f"{ex}")
        return None


@st.cache_data
def calculate_data_quality_score(
    data_df: pd.DataFrame,
    completeness_threshold: str,
    date_range_threshold: str,
    outlier_threshold: str,
    uniqueness_threshold: str,
    selected_catg_num_columns: list[str],
    selected_date_column: list[str],
) -> pd.DataFrame:
    """
    Calculates the data quality score for a given Pandas DataFrame `data_df` based on several \
        threshold parameters.
    The function calculates completeness, date range, outlier percentage, and uniqueness \
        percentage metrics for the input data and then calculates the data quality score \
            based on these metrics and the threshold parameters provided.

    Args:
        data_df (pd.DataFrame): The input Pandas DataFrame.
        completeness_threshold (str): The threshold for completeness metric.
        date_range_threshold (str): The threshold for date range metric.
        outlier_threshold (str): The threshold for outlier metric.
        uniqueness_threshold (str): The threshold for uniqueness metric.
        selected_catg_num_columns (List[str]): List of columns that should be treated as \
            categorical or numerical data.
        selected_date_column (List[str]): List of columns that should be treated as date data.

    Returns:
        A tuple containing the data quality scores and the metrics calculated for the input data.

    """

    def calculate_completeness(data_df: pd.DataFrame):
        completeness = (data_df.count() / len(data_df)) * 100
        return pd.DataFrame({"Completeness": completeness})

    def calculate_duplicate_percentage(data_df: pd.DataFrame):
        duplicate_percentage = 100 - (data_df.duplicated().mean() * 100)
        return duplicate_percentage

    def calculate_uniqueness(data_df: pd.DataFrame, catg_num_columns: list[str]):
        uniqueness = data_df[catg_num_columns].nunique() / len(data_df[catg_num_columns]) * 100
        return pd.DataFrame({"Uniqueness": uniqueness})

    def calculate_date_range(data_df: pd.DataFrame, date_column: str):
        date_range = []
        for col in date_column:
            frequency, ratio = detect_date_frequency(data_df, col)
            missed_periods, ideal_periods = get_missing_dates(data_df, col, frequency)
            range_percentage = (
                (len(ideal_periods) - len(missed_periods)) / len(ideal_periods)
            ) * 100
            date_range.append(range_percentage)
        return pd.DataFrame({"Date Range": date_range}, index=date_column)

    def find_nominal_columns(data_df: pd.DataFrame, max_unique_ratio=0.05):
        """
        Identifies nominal data columns in a dataset.
        Parameters:
            data_df (DataFrame): the input dataset
            max_unique_ratio (float): the maximum ratio of unique values to the number of rows
                in the dataset to consider a column as nominal (default 0.05)
        Returns:
            nominal_cols (list): a list of column names that are considered nominal data
        """
        nominal_cols = []
        for col in data_df.columns:
            if pd.api.types.is_integer_dtype(data_df[col]) or pd.api.types.is_float_dtype(
                data_df[col]
            ):
                unique_ratio = data_df[col].nunique() / len(data_df)
                if unique_ratio <= max_unique_ratio:
                    nominal_cols.append(col)
        return nominal_cols

    def calculate_outliers(data_df: pd.DataFrame, nominal_cols=[]):
        numeric_cols = data_df.select_dtypes(include=np.number).columns
        if nominal_cols:
            numeric_cols = list(set(numeric_cols) - set(nominal_cols))
        outlier_percentage = []
        for col in numeric_cols:
            outlier_stats = detect_outliers(data_df, col, method="robust_z_score")
            outlier_percentage.append(outlier_stats["perc_of_outliers"])
        return pd.DataFrame({"Outlier Percentage": outlier_percentage}, index=numeric_cols)

    def fetch_metrics_values(data_df: pd.DataFrame, unique_cols=None, date_cols=None):
        completeness = calculate_completeness(data_df)
        date_range = pd.DataFrame()
        nominal_cols = find_nominal_columns(data_df)
        outlier_percentage = calculate_outliers(data_df, nominal_cols)
        if unique_cols is not None:
            uniqueness = calculate_uniqueness(data_df, unique_cols)

        # Identify columns with datetime values and calculate date range
        if date_cols is not None:
            date_range = calculate_date_range(data_df, date_cols)

        data_quality = pd.concat([completeness, outlier_percentage], axis=1)

        if unique_cols is not None:
            data_quality = pd.concat([data_quality, uniqueness], axis=1)
        if date_cols is not None:
            data_quality = pd.concat([data_quality, date_range], axis=1)
        data_quality.reset_index(inplace=True)
        data_quality.rename(columns={"index": "Column"}, inplace=True)
        return data_quality

    def calculate_completeness_score(
        data_df: pd.DataFrame, completeness_percentages, completeness_threshold
    ):
        completeness_scores = [
            1 if percentage >= completeness_threshold else 0
            for percentage in completeness_percentages
        ]
        overall_completeness_score = sum(completeness_scores) / len(completeness_percentages)
        return overall_completeness_score

    def calculate_date_range_score(
        data_df: pd.DataFrame, date_range_percentages, date_range_threshold
    ):
        date_range_score = [
            1 if percentage >= date_range_threshold else 0 for percentage in date_range_percentages
        ]
        overall_date_range_score = sum(date_range_score) / len(date_range_percentages)
        return overall_date_range_score

    def calculate_outlier_score(data_df: pd.DataFrame, outlier_percentage, outlier_threshold):
        if len(outlier_percentage) == 0:
            overall_outlier_score = 1
        else:
            outlier_scores = [
                1 if percentage <= outlier_threshold else 0 for percentage in outlier_percentage
            ]
            overall_outlier_score = sum(outlier_scores) / len(outlier_percentage)
        return overall_outlier_score

    def calculate_uniqueness_score(
        data_df: pd.DataFrame, uniqueness_percentage, uniqueness_threshold
    ):
        uniqueness_scores = [
            1 if percentage >= uniqueness_threshold else 0 for percentage in uniqueness_percentage
        ]
        overall_uniqueness_score = sum(uniqueness_scores) / len(uniqueness_percentage)
        return overall_uniqueness_score

    # calculating metrics
    metrics = fetch_metrics_values(
        data_df, unique_cols=selected_catg_num_columns, date_cols=selected_date_column
    )
    final_completeness_score = (
        calculate_completeness_score(
            metrics, metrics["Completeness"].dropna().tolist(), completeness_threshold
        )
        * 100
    )
    final_date_range_score = None
    if "Date Range" in metrics.columns:
        final_date_range_score = (
            calculate_date_range_score(
                metrics, metrics["Date Range"].dropna().tolist(), date_range_threshold
            )
            * 100
        )

    final_outlier_score = (
        calculate_outlier_score(
            metrics, metrics["Outlier Percentage"].dropna().tolist(), outlier_threshold
        )
        * 100
    )

    final_uniqueness_score = None
    if "Uniqueness" in metrics.columns:
        final_uniqueness_score = (
            calculate_uniqueness_score(
                metrics, metrics["Uniqueness"].dropna().tolist(), uniqueness_threshold
            )
            * 100
        )

    duplicate_percentage = calculate_duplicate_percentage(data_df)
    scores_df = pd.DataFrame(
        {
            "Completeness Score": [round(final_completeness_score, 0)],
            "Date Range Score": [round(final_date_range_score, 0)]
            if final_date_range_score is not None
            else [None],
            "Outlier Score": [round(final_outlier_score, 0)],
            "Uniqueness Score": [round(final_uniqueness_score, 0)]
            if final_uniqueness_score is not None
            else [None],
            "Duplicacy Score": [round(duplicate_percentage, 0)],
        }
    )
    return (scores_df, metrics)


@st.cache_data
def analyze_skus(
    df,
    sku_col,
    value_col,
    date_col,
    min_months,
    max_months,
    spike_threshold,
    missing_threshold,
):
    result = {}

    df[date_col] = pd.to_datetime(df[date_col])

    # Filter SKUs based on the provided number of months
    skus_min_months = df.groupby(sku_col).filter(
        lambda x: ((x[date_col].max() - x[date_col].min()).days / 30) >= min_months
    )
    skus_max_months = df.groupby(sku_col).filter(
        lambda x: ((x[date_col].max() - x[date_col].min()).days / 30) <= max_months
    )
    # Calculate the number of SKUs with less than min_months and more than max_months
    num_skus_less_than_min = len(df[sku_col].unique()) - len(skus_min_months[sku_col].unique())
    num_skus_more_than_max = len(df[sku_col].unique()) - len(skus_max_months[sku_col].unique())

    result["num_skus_less_than_min"] = num_skus_less_than_min
    result["num_skus_more_than_max"] = num_skus_more_than_max

    result["skus_list_less_than_min"] = (
        df[~df[sku_col].isin(skus_min_months[sku_col].unique())][sku_col].unique().tolist()
    )
    result["skus_list_more_than_max"] = (
        df[~df[sku_col].isin(skus_max_months[sku_col].unique())][sku_col].unique().tolist()
    )

    # Filter SKUs with erratic spikes or patterns
    df["rolling_mean"] = df.groupby(sku_col)[value_col].transform(
        lambda x: x.rolling(window=3, center=False).mean()
    )
    df["percent_diff"] = (df[value_col] - df["rolling_mean"]).abs() / df["rolling_mean"]
    skus_erratic = (
        df[df["percent_diff"] >= spike_threshold].groupby(sku_col).filter(lambda x: len(x) > 0)
    )
    result["skus_erratic"] = skus_erratic[sku_col].unique().tolist()

    # Filter SKUs with too many missing values
    df["missing"] = df[value_col].isnull().astype(int)
    df["missing_pattern"] = df.groupby(sku_col)["missing"].transform(
        lambda x: x.rolling(window=3, center=False).sum()
    )
    skus_missing = (
        df[df["missing_pattern"] >= missing_threshold]
        .groupby(sku_col)
        .filter(lambda x: len(x) > 0)
    )
    result["skus_missing"] = skus_missing[sku_col].unique().tolist()

    # Calculate the standard deviation of sales for each SKU
    df["std_dev"] = df.groupby(sku_col)[value_col].transform(lambda x: x.std())

    # Set threshold as average standard deviation
    std_dev_threshold = df["std_dev"].mean()

    # Count the number of SKUs above and below the threshold
    num_high_volatility_skus = df[df["std_dev"] > std_dev_threshold][sku_col].nunique()
    num_low_volatility_skus = df[df["std_dev"] <= std_dev_threshold][sku_col].nunique()

    result["num_high_volatility_skus"] = num_high_volatility_skus
    result["num_low_volatility_skus"] = num_low_volatility_skus

    result["skus_list_high_volatility"] = (
        df[df["std_dev"] > std_dev_threshold][sku_col].unique().tolist()
    )
    result["skus_list_low_volatility"] = (
        df[df["std_dev"] <= std_dev_threshold][sku_col].unique().tolist()
    )

    return result


@st.cache_data
def top_skus_by_percentage(df, date_col, cols, top_percentage, n_years, sku_col):
    # Filter data for the last 'n' years
    recent_data = df[df[date_col] >= (datetime.now() - relativedelta(years=n_years))]

    # Calculate the cumulative sum of the selected columns for each SKU
    sku_sums = recent_data.groupby(sku_col)[cols].sum()

    # Calculate the cumulative sum of the selected columns for all SKUs
    total_sums = sku_sums.sum()

    # Identify the SKUs that sum up to the top 'top_percentage' of each column
    top_skus = {}
    for col in cols:
        sku_sums_sorted = sku_sums[col].sort_values(ascending=False)
        cumsum = sku_sums_sorted.cumsum()
        threshold = total_sums[col] * (top_percentage / 100)
        top_skus[col] = sku_sums_sorted[cumsum <= threshold].index.tolist()

    return top_skus


def get_basic_data_cleaning(df: pd.DataFrame, temp_saving: str):
    # Custom CSS styles
    st.markdown(
        """
        <style>
            .stApp {
                max-width: 1200px;
                margin: 0 auto;
            }
            .st-br {
                background-color: #ffffff;
                padding: 1.5rem;
                border-radius: 10px;
                box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
            }
            .st-dataframe {
                font-size: 14px;
            }
            .st-header {
                color: #2e6c80;
                background-color: #f5f9fb;
                padding: 10px;
                border-radius: 10px;
                margin-bottom: 20px;
            }
            .st-summary {
                margin-top: 20px;
                padding: 10px;
                background-color: #f5f9fb;
                border-radius: 10px;
                box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
            }
            .st-info {
                margin-top: 20px;
                padding: 10px;
                background-color: #fff8e5;
                border-radius: 10px;
                box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
            }
            .st-success {
                margin-top: 20px;
                padding: 10px;
                background-color: #e4f8e0;
                border-radius: 10px;
                box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
            }
        </style>
        """,
        unsafe_allow_html=True,
    )

    cleaning_log = pd.DataFrame(columns=["Session", "Step", "Columns"])
    # App title and description
    st.markdown(
        """
        Select the columns to clean and impute. \n
        Choose from various imputation methods and preview the cleaned data \
            along with a summary of the cleaning process.
        """,
        unsafe_allow_html=True,
    )

    st.markdown("### Data Preview")
    st.dataframe(df.head(4))

    st.markdown("## Data Cleaning and Imputation")
    cols_to_clean = st.multiselect("Select columns to clean and impute", df.columns)

    summary_before_cleaning = pd.DataFrame(
        {
            "Columns": cols_to_clean,
            "Count": df[cols_to_clean].count(),
            "Percentage": df[cols_to_clean].count() / len(df) * 100,
            "Mean": df[cols_to_clean].mean(),
            "Std": df[cols_to_clean].std(),
            "Min": df[cols_to_clean].min(),
            "25%": df[cols_to_clean].quantile(0.25),
            "50%": df[cols_to_clean].quantile(0.5),
            "75%": df[cols_to_clean].quantile(0.75),
            "Max": df[cols_to_clean].max(),
            "Null_value": df[cols_to_clean].isnull().sum(),
        }
    )
    st.header("Summary (Before Cleaning)")
    st.dataframe(summary_before_cleaning)

    cleaned_df = df.copy()
    summary = pd.DataFrame(
        columns=[
            "Method",
            "Columns Imputed",
            "Columns Interpolated",
            "Imputation Strategy",
            "Rows Dropped",
            "Duplicates Removed",
            "Rows Imputed",
        ]
    )

    # Procedures
    st.markdown("## Procedure")
    procedure = st.multiselect(
        "Select procedure(s)",
        [
            "Drop Missing Values",
            "Remove Outliers",
            "Remove Duplicates",
            "Statistical Imputation",
        ],
    )

    if "Drop Missing Values" in procedure:
        cleaned_df = cleaned_df.dropna(subset=cols_to_clean)
        cleaning_log = cleaning_log.append(
            {
                "Session": "Current",
                "Step": "Drop Missing Values",
                "Columns": ", ".join(cols_to_clean),
            },
            ignore_index=True,
        )
        summary.loc[3] = [
            "",
            "",
            "",
            "",
            len(df) - len(cleaned_df),
            0,
            len(cleaned_df) - len(df),
        ]

    if "Remove Outliers" in procedure:
        inp_df_copy = cleaned_df.copy(deep=True)
        for col in cols_to_clean:
            data_df = inp_df_copy[inp_df_copy[col].notnull()]
            data = data_df[col].values
            THRESHOLD = 3.5
            overall_med = np.median(data)
            mad = np.median([np.abs(val - overall_med) for val in data])
            modified_z_scores = [0.6745 * (val - overall_med) / mad for val in data]

            logger.debug(
                f"overall_med = {overall_med} \n mad= {mad} \n max score = {max(modified_z_scores)}"
            )

            unique_outlier_values = set(
                [
                    data[i]
                    for i in range(len(modified_z_scores))
                    if np.abs(modified_z_scores[i]) > THRESHOLD
                ]
            )

            outlier_rows = inp_df_copy[inp_df_copy[col].isin(unique_outlier_values)]
            unique_outlier_indexes = outlier_rows[
                ~outlier_rows.duplicated(subset=col)
            ].index.tolist()

            cleaned_df = cleaned_df.drop(unique_outlier_indexes)

            cleaning_log = cleaning_log.append(
                {"Session": "Current", "Step": "Remove Outliers", "Columns": col},
                ignore_index=True,
            )

            summary.loc[4] = [
                "",
                "",
                "",
                "",
                len(df) - len(cleaned_df),
                0,
                len(cleaned_df) - len(df),
            ]

    if "Remove Duplicates" in procedure:
        duplicates_count = len(df) - len(df.drop_duplicates(subset=cols_to_clean))
        st.info(f"Number of duplicates in selected columns: {duplicates_count}")
        cleaned_df.drop_duplicates(keep="first", inplace=True)
        cleaning_log = cleaning_log.append(
            {
                "Session": "Current",
                "Step": "Remove Duplicates",
                "Columns": ", ".join(cols_to_clean),
            },
            ignore_index=True,
        )
        summary.loc[5] = [
            "Remove Duplicates",
            "",
            "",
            "",
            0,
            len(df) - len(cleaned_df),
            len(cleaned_df) - len(df),
        ]

    if "Statistical Imputation" in procedure:
        custom_impute_method = st.selectbox(
            "Select an imputation method",
            [
                "Mean Imputation",
                "Median Imputation",
                "Mode Imputation",
                "Linear Interpolation",
                "Most Frequent",
            ],
        )
        numeric_cols = cleaned_df[cols_to_clean].select_dtypes(include=[np.number]).columns
        object_cols = cleaned_df[cols_to_clean].select_dtypes(include=[object]).columns

        if len(object_cols) > 0 and custom_impute_method not in [
            "Mode Imputation",
            "Most Frequent",
        ]:
            st.error("Cannot impute object columns: " + ", ".join(object_cols))
        else:
            if custom_impute_method == "Mean Imputation":
                imputer = SimpleImputer(strategy="mean")
                cleaned_df[cols_to_clean] = imputer.fit_transform(cleaned_df[cols_to_clean])
                cleaning_log = cleaning_log.append(
                    {
                        "Session": "Current",
                        "Step": "Statistical Imputation - Mean",
                        "Columns": ", ".join(cols_to_clean),
                    },
                    ignore_index=True,
                )
                summary.loc[6] = [
                    "Statistical Imputation",
                    ", ".join(cols_to_clean),
                    "",
                    "Mean",
                    0,
                    0,
                    len(cleaned_df) - len(df),
                ]

            elif custom_impute_method == "Median Imputation":
                imputer = SimpleImputer(strategy="median")
                cleaned_df[cols_to_clean] = imputer.fit_transform(cleaned_df[cols_to_clean])
                cleaning_log = cleaning_log.append(
                    {
                        "Session": "Current",
                        "Step": "Statistical Imputation - Median",
                        "Columns": ", ".join(cols_to_clean),
                    },
                    ignore_index=True,
                )
                summary.loc[6] = [
                    "Statistical Imputation",
                    ", ".join(cols_to_clean),
                    "",
                    "Median",
                    0,
                    0,
                    len(cleaned_df) - len(df),
                ]

            elif (
                custom_impute_method == "Mode Imputation"
                or custom_impute_method == "Most Frequent"
            ):
                imputer = SimpleImputer(strategy="most_frequent")
                cleaned_df[cols_to_clean] = imputer.fit_transform(cleaned_df[cols_to_clean])
                cleaning_log = cleaning_log.append(
                    {
                        "Session": "Current",
                        "Step": "Statistical Imputation - Mode"
                        if custom_impute_method == "Mode Imputation"
                        else "Statistical Imputation - Most Frequent",
                        "Columns": ", ".join(cols_to_clean),
                    },
                    ignore_index=True,
                )
                summary.loc[6] = [
                    "Statistical Imputation",
                    ", ".join(cols_to_clean),
                    "",
                    "Mode" if custom_impute_method == "Mode Imputation" else "Most Frequent",
                    0,
                    0,
                    len(cleaned_df) - len(df),
                ]

            elif custom_impute_method == "Linear Interpolation":
                cleaned_df[numeric_cols] = cleaned_df[numeric_cols].interpolate(method="linear")
                cleaning_log = cleaning_log.append(
                    {
                        "Session": "Current",
                        "Step": "Statistical Imputation - Linear Interpolation",
                        "Columns": ", ".join(cols_to_clean),
                    },
                    ignore_index=True,
                )
                summary.loc[6] = [
                    "Statistical Imputation",
                    "",
                    ", ".join(cols_to_clean),
                    "Linear Interpolation",
                    0,
                    0,
                    0,
                ]

    clean_button = st.button("Clean and Impute")
    # Continue the process after the button is clicked!!
    if clean_button:
        st.text("Cleaning and imputing data...")
        # Perform the cleaning and imputation steps here

        # Update the summary after cleaning and imputation
        summary_after_cleaning = pd.DataFrame(
            {
                "Columns": cols_to_clean,
                "Count": cleaned_df[cols_to_clean].count(),
                "Percentage": cleaned_df[cols_to_clean].count() / len(cleaned_df) * 100,
                "Mean": cleaned_df[cols_to_clean].mean(),
                "Std": cleaned_df[cols_to_clean].std(),
                "Min": cleaned_df[cols_to_clean].min(),
                "25%": cleaned_df[cols_to_clean].quantile(0.25),
                "50%": cleaned_df[cols_to_clean].quantile(0.5),
                "75%": cleaned_df[cols_to_clean].quantile(0.75),
                "Max": cleaned_df[cols_to_clean].max(),
                "Null_value": cleaned_df[cols_to_clean].isnull().sum(),
            }
        )
        st.header("Summary (After Cleaning)")
        st.dataframe(summary_after_cleaning)

        st.header("Cleaned Data Preview")
        st.dataframe(cleaned_df.head(10))

        st.header("Cleaning Log")
        st.dataframe(cleaning_log)

        st.write("")

        if temp_saving == "No":
            # ->1. client database has mapping table and table name selected by user has bronze_ in it:
            if (
                st.session_state.selected_database_name_from_user is not None
                and st.session_state.selected_table_name_from_user is not None
            ):
                new_file_name = (
                    "silver_"
                    + st.session_state.selected_table_name_from_user.split("_")[1]
                    + ".csv"
                )
                st.session_state.new_updated_dataset = new_file_name
                file_path = os.path.join(st.session_state.datasets_dir, new_file_name)
                cleaned_df.to_csv(
                    file_path,
                    index=False,
                    header=True,
                )
                st.write(
                    f"The stored file name: \
                        {new_file_name} and the format of the file is CSV"
                )
                st.write("")
                st.write("")
                # creatig a path to push into the dbfs
                st.session_state.dbfs_push_path = f"/Innover1/{st.session_state.selected_database_name_from_user}/{new_file_name}"
                st.warning("Please navigate to step 2")

            else:
                new_file_name = "cleaned_" + st.session_state.dataset
                st.session_state.new_updated_dataset = new_file_name
                file_path = os.path.join(st.session_state.datasets_dir, new_file_name)
                cleaned_df.to_csv(
                    file_path,
                    index=False,
                    header=True,
                )
                st.write(
                    f"The stored file name: \
                        {new_file_name} and the format of the file is CSV"
                )
                st.write("")
                st.warning("Please navigate to step 2")

        else:
            if (
                st.session_state.selected_database_name_from_user is not None
                and st.session_state.selected_table_name_from_user is not None
            ):
                new_file_name = (
                    "basic_cleaning_"
                    + st.session_state.selected_table_name_from_user.split("_")[1]
                    + ".csv"
                )
                file_path = os.path.join(st.session_state.datasets_dir, new_file_name)
                cleaned_df.to_csv(
                    file_path,
                    index=False,
                    header=True,
                )
                st.write(
                    f"The stored file name: \
                        {new_file_name} and the format of the file is CSV"
                )
                st.write("")
                st.warning("Please navigate to step 2")

            else:
                new_file_name = "basic_cleaning_" + st.session_state.dataset
                file_path = os.path.join(st.session_state.datasets_dir, new_file_name)
                cleaned_df.to_csv(
                    file_path,
                    index=False,
                    header=True,
                )
                st.write(
                    f"The stored file name: \
                        {new_file_name} and the format of the file is CSV"
                )
                st.write("")
                st.warning("Please navigate to step 2")


def get_advanced_data_cleaning(df: pd.DataFrame, temp_saving: str):
    # Input fields for column selection
    st.write("")
    st.write("")
    sku_col = st.selectbox("Select SKU column", options=tuple([""] + df.columns.tolist()))
    value_col = st.selectbox("Select value column", options=tuple([""] + df.columns.tolist()))
    date_col = st.selectbox("Select date column", options=tuple([""] + df.columns.tolist()))

    if sku_col != "" and value_col != "" and date_col != "":
        df[date_col] = df[date_col].astype("str")
        df[date_col] = pd.to_datetime(df[date_col])
        # Input fields for finding top SKUs
        with st.container():
            st.header("Top SKUs")
            # Input fields for finding top SKUs
            n_years_key = "n_years_input"
            n_years = 5  # Hardcoded value: 5 years
            top_percentage_key = "top_percentage_input"
            top_percentage = 80  # Hardcoded value: 80%
            value_cols_key = "value_cols_input"
            value_cols = [value_col]
            # Display hardcoded values
            st.write("**Predefined Values:**")
            st.write(f"- Last 'n' years: {n_years}")
            st.write(f"- Top percentage: {top_percentage}%")

            keep_skus_dict = {}
            top_skus = top_skus_by_percentage(
                df, date_col, value_cols, top_percentage, n_years, sku_col
            )
            keep_skus_dict = {}
            for col in value_cols:
                st.markdown(f"**Column: '{col}'**")
                top_skus_col = top_skus[col]
                n_top_skus = len(top_skus_col)
                total_skus = len(df[sku_col].unique())
                percentage = (n_top_skus / total_skus) * 100
                keep_skus = True
                keep_skus_dict[col] = keep_skus

            selected_skus = []
            for col, keep_skus in keep_skus_dict.items():
                if keep_skus:
                    selected_skus.extend(top_skus[col])

            # Print the number of SKUs finally in the list
            num_selected_skus = len(selected_skus)
            # Perform union operation and display the number of SKUs finally in the list
            st.write(f"Number of SKUs finally in the list: {num_selected_skus}")
            # saving the cleaned file
        cleaned_data = df.copy()
        # Filtering Criteria
        with st.container():
            st.header("Filtering Criteria")
            min_months_key = "Minimum months of data"
            min_months = 2
            max_months_key = "Maximum months of data"
            max_months = 60
            spike_threshold_key = "Spike threshold (in % of rolling mean)"
            spike_threshold = 0.3
            missing_threshold_keys = "Missing values threshold"
            missing_threshold = 2
            # Display hardcoded values
            st.write("**Predefined Values:**")
            st.write(f"- Minimum months of data: {min_months}")
            st.write(f"- Maximum months of data: {max_months}")
            st.write(f"- Spike threshold (in % of rolling mean): {30}%")
            st.write(f"- Missing values threshold: {missing_threshold}0%")

        # Analyze SKUs
        # if st.button("Analyze SKUs"):
        result = analyze_skus(
            cleaned_data,
            sku_col,
            value_col,
            date_col,
            min_months,
            max_months,
            spike_threshold,
            missing_threshold,
        )

        # Calculate the total number of SKUs
        total_skus = len(cleaned_data[sku_col].unique())
        # Calculate the number of SKUs with less than min_months and their percentage
        num_skus_less_than_min = result["num_skus_less_than_min"]
        perc_skus_less_than_min = (num_skus_less_than_min / total_skus) * 100

        # Calculate the number of SKUs with more than max_months and their percentage
        num_skus_more_than_max = result["num_skus_more_than_max"]
        perc_skus_more_than_max = (num_skus_more_than_max / total_skus) * 100

        # Create a dictionary to store the selected actions (keep/remove) for each SKU
        sku_actions = {}
        st.write("Please complete the below process:")
        # Display the insights in a more visually appealing format using expanders
        with st.expander("Insights"):
            st.write(
                f"**{num_skus_less_than_min} SKUs ({perc_skus_less_than_min:.2f}%)** have less than {min_months} months of data."
            )
            action_less_than_min = st.checkbox("Keep SKUs", value=True, key="action_less_than_min")
            sku_actions["skus_list_less_than_min"] = action_less_than_min

            st.write(
                f"**{num_skus_more_than_max} SKUs ({perc_skus_more_than_max:.2f}%)** have more than {max_months} months of data."
            )
            action_more_than_max = st.checkbox("Keep SKUs", value=True, key="action_more_than_max")
            sku_actions["skus_list_more_than_max"] = action_more_than_max

            st.write("**SKUs with erratic spikes/patterns:**", result["skus_erratic"])
            action_erratic = st.checkbox("Keep SKUs", value=True, key="action_erratic")
            sku_actions["skus_erratic"] = action_erratic

            st.write("**SKUs with too many missing values:**", result["skus_missing"])
            action_missing = st.checkbox("Keep SKUs", value=True, key="action_missing")
            sku_actions["skus_missing"] = action_missing

            st.write(
                "**Number of highly volatile SKUs:**",
                result["num_high_volatility_skus"],
            )
            action_high_volatility = st.checkbox(
                "Keep SKUs", value=True, key="action_high_volatility"
            )
            sku_actions["skus_list_high_volatility"] = action_high_volatility

            st.write("**Number of low volatile SKUs:**", result["num_low_volatility_skus"])
            action_low_volatility = st.checkbox(
                "Keep SKUs", value=True, key="action_low_volatility"
            )
            sku_actions["skus_list_low_volatility"] = action_low_volatility

            insights_form_submit_button = st.button("Execute")

        skus_to_drop = []
        skus_to_keep = []
        # Update the lists of SKUs to drop or keep based on the selected actions
        for key, action in sku_actions.items():
            if action:  # If checkbox is checked (Keep)
                skus_to_keep.extend(
                    result[key] if isinstance(result[key], (list, tuple, set)) else [result[key]]
                )

            else:  # If checkbox is unchecked (Drop)
                skus_to_drop.extend(
                    result[key] if isinstance(result[key], (list, tuple, set)) else [result[key]]
                )
        # Get the union of all SKUs to drop
        cleaned_df = cleaned_data[
            ~cleaned_data[sku_col].isin(list(set(skus_to_drop)))
        ]  # final data

        if insights_form_submit_button:
            # Print the number of SKUs finally in the list
            num_selected_skus = cleaned_df[sku_col].nunique()
            st.write(f"Total number of SKUs: {total_skus}")
            st.write(f"Number of SKUs finally in the list: {num_selected_skus}")
            st.write(f"Total Shape of a Cleaned DataFrame: {cleaned_df.shape}")

            st.write("")
            if temp_saving == "No":
                if (
                    st.session_state.selected_database_name_from_user is not None
                    and st.session_state.selected_table_name_from_user is not None
                ):
                    new_file_name = (
                        "silver_"
                        + st.session_state.selected_table_name_from_user.split("_")[1]
                        + ".csv"
                    )
                    st.session_state.new_updated_dataset = new_file_name
                    file_path = os.path.join(st.session_state.datasets_dir, new_file_name)
                    cleaned_df.to_csv(
                        file_path,
                        index=False,
                        header=True,
                    )
                    st.write(
                        f"The stored file name: \
                            {new_file_name} and the format of the file is CSV"
                    )
                    st.write("")
                    st.write("")
                    # creatig a path to push into the dbfs
                    st.session_state.dbfs_push_path = f"/Innover1/{st.session_state.selected_database_name_from_user}/{new_file_name}"
                    st.warning("Please navigate to step 2")

                else:
                    new_file_name = "advanced_cleaning_" + st.session_state.dataset
                    st.session_state.new_updated_dataset = new_file_name
                    file_path = os.path.join(st.session_state.datasets_dir, new_file_name)
                    cleaned_df.to_csv(
                        file_path,
                        index=False,
                        header=True,
                    )
                    st.write(
                        f"The stored file name: \
                            {new_file_name} and the format of the file is CSV"
                    )
                    st.write("")
                    st.warning("Please navigate to step 2")

            else:
                if (
                    st.session_state.selected_database_name_from_user is not None
                    and st.session_state.selected_table_name_from_user is not None
                ):
                    new_file_name = (
                        "silver_"
                        + st.session_state.selected_table_name_from_user.split("_")[1]
                        + ".csv"
                    )
                    st.session_state.new_updated_dataset = new_file_name
                    file_path = os.path.join(st.session_state.datasets_dir, new_file_name)
                    cleaned_df.to_csv(
                        file_path,
                        index=False,
                        header=True,
                    )
                    st.write(
                        f"The stored file name: \
                            {new_file_name} and the format of the file is CSV"
                    )
                    st.write("")

                    # creatig a path to push into the dbfs
                    st.session_state.dbfs_push_path = f"/Innover1/{st.session_state.selected_database_name_from_user}/{new_file_name}"
                    st.warning("Please navigate to step 3!!")

                else:
                    new_file_name = "advanced_cleaning_" + st.session_state.dataset
                    st.session_state.new_updated_dataset = new_file_name
                    file_path = os.path.join(st.session_state.datasets_dir, new_file_name)
                    cleaned_df.to_csv(
                        file_path,
                        index=False,
                        header=True,
                    )
                    st.write(
                        f"The stored file name: \
                            {new_file_name} and the format of the file is CSV"
                    )
                    st.write("")
                    st.warning("Please navigate to step 3!!")


def push_data_to_dbfs(file_name):
    if st.session_state.dbfs_push_path is not None:
        # 1. Creating the connection to the deltatable to access 2 tables from 2 diff database
        databricks_pat = "dapiaa7b7b8e92adbce1f90be9b44b1649a5-3"
        server_hostname = "adb-2192895227016004.4.azuredatabricks.net"
        destination_path = st.session_state.dbfs_push_path
        # 5.1 Confurigation for the dbfs connection
        access_token = databricks_pat
        url = f"https://{server_hostname}/api/2.0/dbfs/put"
        local_path = f"{os.path.join(st.session_state.datasets_dir, file_name)}"
        # 5.2 Open the file and read its contents
        with open(local_path, "rb") as file:
            file_content = file.read()
        # 5.3 Prepare the request payload
        payload = {
            "path": (None, destination_path),
            "overwrite": (None, "true"),
            "contents": (destination_path, file_content),
        }
        # 5.4 Send the request to upload the file
        headers = {"Authorization": "Bearer " + access_token}
        response = requests.post(url, headers=headers, files=payload)
        # 5.5 Check the response
        if response.status_code == 200:
            st.warning("File uploaded successfully.")
            st.write(
                f"The File has been stored in this file path: \
                    {destination_path} and the format of the file is CSV"
            )
        else:
            st.warning(f"Error uploading file:{response.text}")
    else:
        # Creating a push path manually
        # creatig a path to push into the dbfs
        st.subheader("Creating a Path to Push into the DBFS")
        st.markdown(
            """
            - Please enter the <dbfs> path manually just like it shown in the \
                example.
            - Syntax: /MAIN_FOLDER_NAME/CLIENT_NAME OR DATABASE_NAME OR ANY_NAME\
                (eg: /Testing/bluelinx)"""
        )
        push_path = st.text_input("")
        save_path = st.button("CREATE PATH")
        if save_path is True:
            st.session_state.dbfs_push_path = f"{push_path}/{file_name}"
            # 1. Creating the connection to the deltatable to access 2 tables from 2 diff database
            databricks_pat = "dapiaa7b7b8e92adbce1f90be9b44b1649a5-3"
            server_hostname = "adb-2192895227016004.4.azuredatabricks.net"
            destination_path = st.session_state.dbfs_push_path
            # 5.1 Confurigation for the dbfs connection
            access_token = databricks_pat
            url = f"https://{server_hostname}/api/2.0/dbfs/put"
            local_path = f"{os.path.join(st.session_state.datasets_dir, file_name)}"
            # 5.2 Open the file and read its contents
            with open(local_path, "rb") as file:
                file_content = file.read()
            # 5.3 Prepare the request payload
            payload = {
                "path": (None, destination_path),
                "overwrite": (None, "true"),
                "contents": (destination_path, file_content),
            }
            # 5.4 Send the request to upload the file
            headers = {"Authorization": "Bearer " + access_token}
            response = requests.post(url, headers=headers, files=payload)
            # 5.5 Check the response
            if response.status_code == 200:
                st.warning("File uploaded successfully.")
                st.write(
                    f"The File has been stored in this file path: \
                        {destination_path} and the format of the file is CSV"
                )
            else:
                st.warning(f"Error uploading file:{response.text}")
