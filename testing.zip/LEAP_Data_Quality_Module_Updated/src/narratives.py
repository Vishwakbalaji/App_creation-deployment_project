APP_MODULES_TREE = {
    "name": "App",
    "children": [
        {
            "name": "Data Console",
            "children": [
                {"name": "File upload"},
                {"name": "Data Selector"},
                {"name": "Data Preview"},
            ],
        },
        {
            "name": "Data Quality",
            "children": [
                {"name": "Duplicates"},
                {"name": "Completeness"},
                {"name": "Missing correlations"},
                {"name": "column-wise data quality kpis"},
            ],
        },
        {
            "name": "Univariate",
            "children": [
                {
                    "name": "numeric",
                    "children": [
                        {"name": "Distribution summaries"},
                        {"name": "Outliers"},
                    ],
                },
                {"name": "categorical", "children": [{"name": "frequency distribution"}]},
                {
                    "name": "temporal",
                    "children": [{"name": "date frequency"}, {"name": "missing dates"}],
                },
            ],
        },
        {"name": "Bivariate+", "children": [{"name": "relationship between 2 variables"}]},
    ],
}

UNIVARIATE_NUMERIC = {
    "outliers_description": "Number of outliers found = :red[{n_outliers}]  \n"
    "Number of unique outliers = :red[{n_unique_outliers}]  \n"
    "Outliers represent :red[{perc_of_outliers}%] of the entire dataset (total non-null rows in dataset =:red[{n_rows}]).  \n",
    "outliers_right": "Outliers range : {colname} > :red[{outlier_boundary_right}]",
    "outliers_left": "Outliers range : {colname} < :red[{outlier_boundary_left}]",
    "outliers_left_and_right": "Outliers range : {colname} :red[{outlier_boundary_left}] (or) {colname} > :red[{outlier_boundary_right}]",
}
