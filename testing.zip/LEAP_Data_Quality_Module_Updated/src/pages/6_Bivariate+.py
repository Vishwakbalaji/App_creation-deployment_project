import os

import numpy as np

# import pandas as pd
import streamlit as st

from accelerator_utils import (
    get_categorical_by_categorical_aggregates,
    get_categorical_by_numeric_aggregates,
    get_data_df,
    get_date_by_numeric_aggregates,
    get_date_column_univariate_insights,
)
from app_utils import (
    init_app,
    leap_logo,
    make_header,
    make_topbar_logo_header,
    update_session_state,
)
from plot_utils import (
    make_barplot,
    make_date_vs_numeric_lineplot,
    make_heatmap,
    make_scatterplot,
)

# from pandas.api.types import is_numeric_dtype


init_app()
leap_logo()
make_topbar_logo_header(text="Data Accelerator")
make_header(text="Bivariate+")
update_session_state()

if st.session_state["logged_in"] is True:
    if "dataset" not in st.session_state:
        st.error(
            body="No dataset selected. Please navigate to Data Console tab and select a dataset."
        )
        st.stop()
    else:
        filepath = os.path.join(st.session_state.datasets_dir, st.session_state.dataset)
        df = get_data_df(filepath)
        if df is None:
            st.error(body="Unable to read dataset. Check logs for details.")
            st.stop()

    all_cols = df.columns.tolist()
    categorical_cols = [colname for colname in all_cols if str(df[colname].dtype) == "object"]
    numerical_cols = [
        colname for colname in all_cols if np.issubdtype(df[colname].dtype, np.number)
    ]
    date_cols = [colname for colname in all_cols if str(df[colname].dtype) == "datetime64[ns]"]

    def update_session_state_bivariate():
        """
        Upon dataset change / bivariate type change, delete the session state history for selectors
        """
        for session_key in [
            "col_bivariate_numeric_1",
            "col_bivariate_numeric_2",
            "col_bivariate_categorical_color",
            "col_bivariate_numeric_size",
            "col_bivariate_categorical_1",
            "col_bivariate_categorical_2",
            "col_bivariate_agg_numeric",
            "col_bivariate_agg_func",
            "col_bivariate_agg_funcs",
            "col_bivariate_date_col",
        ]:
            if session_key in st.session_state:
                del st.session_state[session_key]

    if st.session_state.bivariate_type_idx == -1:
        update_session_state_bivariate()

        # when dataset is changed in data console / first time in this page after change
        if len(numerical_cols) > 2:
            # 1 st priority for 2 numericals
            st.session_state.bivariate_type_idx = 0
        elif numerical_cols and categorical_cols:
            st.session_state.bivariate_type_idx = 1
        elif len(categorical_cols) > 2:
            st.session_state.bivariate_type_idx = 2
        elif numerical_cols and date_cols:
            st.session_state.bivariate_type_idx = 3
        else:
            st.warning("Not enough columns for bivariate analysis.")
            st.stop()

    st.radio(
        label="Bivariate type",
        key="bivariate_type",
        options=[
            "2 numericals",
            "numerical vs categorical",
            "2 categoricals",
            "date vs numerical",
        ],
        horizontal=True,
        index=st.session_state.bivariate_type_idx,
        on_change=update_session_state_bivariate,
    )

    if st.session_state.bivariate_type == "2 numericals":
        if len(numerical_cols) >= 2:
            col1, col2, col3, col4 = st.columns(spec=4, gap="medium")
            with col1:
                st.selectbox(
                    key="col_bivariate_numeric_1",
                    label="Numerical column 1",
                    options=numerical_cols,
                )
            with col2:
                st.selectbox(
                    key="col_bivariate_numeric_2",
                    label="Numerical column 2",
                    options=numerical_cols,
                    index=1,
                )
            with col3:
                st.selectbox(
                    key="col_bivariate_categorical_color",
                    label="Categorical column for filter",
                    options=["--Select--"] + categorical_cols,
                )
            with col4:
                st.selectbox(
                    key="col_bivariate_numeric_size",
                    label="Numeric column to size",
                    options=["--Select--"]
                    + [
                        colname
                        for colname in numerical_cols
                        if colname
                        not in [
                            st.session_state.col_bivariate_numeric_1,
                            st.session_state.col_bivariate_numeric_2,
                        ]
                    ],
                )
        else:
            st.warning(
                "Not enough columns found for this type of analysis. Select a different bivariate type."
            )
    elif st.session_state.bivariate_type == "numerical vs categorical":
        if numerical_cols and categorical_cols:
            col1, col2, col3 = st.columns(spec=3, gap="medium")
            with col1:
                st.selectbox(
                    key="col_bivariate_numeric_1",
                    label="Numerical column",
                    options=numerical_cols,
                )
            with col2:
                st.selectbox(
                    key="col_bivariate_categorical_1",
                    label="Categorical column",
                    options=categorical_cols,
                )
            with col3:
                st.multiselect(
                    key="col_bivariate_agg_funcs",
                    label="Aggregation functions",
                    options=["Average", "Median", "Sum", "Minimum", "Maximum"],
                    default="Average",
                )
        else:
            st.warning(
                "Not enough columns found for this type of analysis. Select a different bivariate type."
            )
    elif st.session_state.bivariate_type == "2 categoricals":
        if len(categorical_cols) >= 2:
            col1, col2, col3, col4 = st.columns(spec=4, gap="medium")
            with col1:
                st.selectbox(
                    key="col_bivariate_categorical_1",
                    label="Categorical column 1",
                    options=categorical_cols,
                )
            with col2:
                st.selectbox(
                    key="col_bivariate_categorical_2",
                    label="Categorical column 2",
                    options=categorical_cols,
                    index=1,
                )
            with col3:
                st.selectbox(
                    key="col_bivariate_agg_numeric",
                    label="Aggregation column",
                    options=["--Select--"] + numerical_cols,
                )
            with col4:
                st.selectbox(
                    key="col_bivariate_agg_func",
                    label="Aggregation functions",
                    options=["--Select--", "Average", "Sum", "Median", "Minimum", "Maximum"],
                )
        else:
            st.warning(
                "Not enough columns found for this type of analysis. Select a different bivariate type."
            )
    elif st.session_state.bivariate_type == "date vs numerical":
        if numerical_cols and date_cols:
            col1, col2, col3 = st.columns(spec=3, gap="medium")
            with col1:
                st.selectbox(
                    key="col_bivariate_date_col",
                    label="Date column",
                    options=date_cols,
                    # index=st.session_state.col1_bivariate_categorical_idx,
                )
            with col2:
                st.selectbox(
                    key="col_bivariate_numeric_1",
                    label="Numerical column",
                    options=numerical_cols,
                )
            with col3:
                st.multiselect(
                    key="col_bivariate_agg_funcs",
                    label="Aggregation functions",
                    options=["Average", "Median", "Sum", "Minimum", "Maximum"],
                    default="Average",
                )
        else:
            st.warning(
                "Not enough columns found for this type of analysis. Select a different bivariate type."
            )

    def show_bivariate_results():
        if st.session_state.bivariate_type == "2 numericals":
            # scatter plot for numeric col1 vs numeric col2
            st.components.v1.html(
                make_scatterplot(
                    data_df=df.sample(min(1000, df.shape[0])),
                    col_x=st.session_state.col_bivariate_numeric_1,
                    col_y=st.session_state.col_bivariate_numeric_2,
                    col_color=st.session_state.col_bivariate_categorical_color
                    if st.session_state.col_bivariate_categorical_color != "--Select--"
                    else None,
                    col_size=st.session_state.col_bivariate_numeric_size
                    if st.session_state.col_bivariate_numeric_size != "--Select--"
                    else None,
                ),
                width=500,
                height=500,
            )
        elif st.session_state.bivariate_type == "2 categoricals":
            if (
                df[st.session_state.col_bivariate_categorical_1].nunique() > 1000
                or df[st.session_state.col_bivariate_categorical_2].nunique() > 1000
            ):
                st.warning("selected columns have high cardinality. try different columns...")
            else:
                agg_col = (
                    None
                    if st.session_state.col_bivariate_agg_numeric == "--Select--"
                    else st.session_state.col_bivariate_agg_numeric
                )
                if agg_col and st.session_state.col_bivariate_agg_func == "--Select--":
                    st.warning("Select an aggregation function.")
                else:
                    agg_df = get_categorical_by_categorical_aggregates(
                        data_df=df,
                        col1=st.session_state.col_bivariate_categorical_1,
                        col2=st.session_state.col_bivariate_categorical_2,
                        agg_col=agg_col,
                        agg_func=st.session_state.col_bivariate_agg_func,
                    )
                    st.components.v1.html(
                        make_heatmap(
                            data_df=agg_df,
                            col_x=st.session_state.col_bivariate_categorical_1,
                            col_y=st.session_state.col_bivariate_categorical_2,
                            col_value="frequency" if agg_col is None else agg_col,
                        ),
                        scrolling=False,
                        height=500,
                        width=600,
                    )
        elif st.session_state.bivariate_type == "numerical vs categorical":
            # bar plot for categorical vs numerical
            agg_df = get_categorical_by_numeric_aggregates(
                data_df=df,
                categorical_col=st.session_state.col_bivariate_categorical_1,
                numeric_col=st.session_state.col_bivariate_numeric_1,
                agg_funcs=st.session_state.col_bivariate_agg_funcs,
            )
            st.components.v1.html(
                make_barplot(
                    data_df=agg_df,
                    x_axis_col=st.session_state.col_bivariate_categorical_1,
                    y_axis_cols=st.session_state.col_bivariate_agg_funcs,
                ),
                height=500,
                width=600,
            )
        elif st.session_state.bivariate_type == "date vs numerical":
            # bar plot for categorical vs numerical
            dt_result = get_date_column_univariate_insights(
                inp_df=df, col=st.session_state.col_bivariate_date_col
            )
            if dt_result is None:
                st.error("Problem in computing date insights, check logs for details.")
                st.stop()
            date_freq_all = [
                "yearly",
                "quarterly",
                "monthly",
                "weekly",
                "daily",
                "hourly",
                "minute-level",
                "second-level",
            ]
            ds_freq = dt_result["dt_frequency"]
            ds_freq_agg_options = date_freq_all[: date_freq_all.index(ds_freq) + 1]
            st.selectbox(
                key="dt_freq_agg",
                label=f"Dataset frequency is {ds_freq}. Aggregate at a different frequency ?",
                options=ds_freq_agg_options,
                index=len(ds_freq_agg_options) - 1
                if "dt_freq_agg" not in st.session_state
                else ds_freq_agg_options.index(st.session_state.dt_freq_agg),
            )
            agg_df = get_date_by_numeric_aggregates(
                inp_df=df,
                date_col=st.session_state.col_bivariate_date_col,
                numeric_col=st.session_state.col_bivariate_numeric_1,
                agg_freq=st.session_state.dt_freq_agg,
                agg_funcs=st.session_state.col_bivariate_agg_funcs,
            )
            st.components.v1.html(
                make_date_vs_numeric_lineplot(
                    data_df=agg_df,
                    x_axis_col=st.session_state.col_bivariate_date_col,
                    y_axis_cols=st.session_state.col_bivariate_agg_funcs,
                    y_axis_name=st.session_state.col_bivariate_numeric_1,
                ),
                height=500,
                width=600,
            )
        else:
            st.write("Coming soon !!")

    if st.button(label="Apply Selections"):
        show_bivariate_results()
else:
    st.error("You still haven't signed in. Login by going to the User Login page.")
