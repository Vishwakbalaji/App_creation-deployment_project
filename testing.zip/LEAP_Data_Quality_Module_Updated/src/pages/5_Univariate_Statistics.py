"""
This module aims to provide facility to explore data one variable at a time.
Distributions of numeric variable, frequency count for categorical variable.
Basically univariate analysis results for selected variables are shown here.
"""
import os

import numpy as np
import pandas as pd
import streamlit as st
from pandas.api.types import is_numeric_dtype

import narratives as narratives
from accelerator_utils import (
    detect_outliers,
    get_column_summary,
    get_cumulative_percent,
    get_data_df,
    get_date_column_univariate_insights,
    get_distribution_quartiles,
    get_frequency_counts,
    get_histogram,
)
from app_utils import (
    init_app,
    leap_logo,
    make_header,
    make_topbar_logo_header,
    update_session_state,
)
from plot_utils import make_barplot, make_boxplot, make_histogram1d, make_pareto_plot

init_app()
leap_logo()
make_topbar_logo_header(text="Data Accelerator")
make_header(text="Univariate Statistics")
update_session_state()

if st.session_state["logged_in"] is True:
    if "dataset" not in st.session_state:
        st.error(
            body="No dataset selected. Please navigate to Data Console tab and select a dataset."
        )
        st.stop()
    else:
        filepath = os.path.join(st.session_state.datasets_dir, st.session_state.dataset)
        df = get_data_df(filepath)
        if df is None:
            st.error(body="Unable to read dataset. Check logs for details.")
            st.stop()

    all_cols = df.columns.tolist()
    numerical_cols = [
        colname for colname in all_cols if np.issubdtype(df[colname].dtype, np.number)
    ]

    def update_session_state_univariate():
        """
        Upon dataset change delete the session state history for selectors
        """
        for session_key in [
            "col_univariate",
            "pareto_col_numeric",
            "col_univariate_agg_funcs",
        ]:
            if session_key in st.session_state:
                del st.session_state[session_key]

    if st.session_state.ds_changed is True:
        update_session_state_univariate()
        st.session_state.ds_changed = False

    if "col_univariate" not in st.session_state:
        selected_col_index = 0
    else:
        if st.session_state.col_univariate in all_cols:
            selected_col_index = all_cols.index(st.session_state.col_univariate)
        else:
            # when dataset is changed in data console, st.session_state.col_univariate has to be
            # refreshed
            # else it will hold a variable from previous ds that is not a column in current ds
            selected_col_index = 0

    comp_col_univariate = st.selectbox(
        key="col_univariate", label="Select a column", options=all_cols, index=selected_col_index
    )

    # section data quality
    st.subheader("Data Quality summary")
    col_summary = get_column_summary(df, st.session_state.col_univariate)
    st.table(pd.DataFrame([col_summary]))

    # section - data distribution
    st.subheader("Data Distribution summary")
    if is_numeric_dtype(df[st.session_state.col_univariate]):
        dist_stats = get_distribution_quartiles(df, st.session_state.col_univariate)
        if dist_stats is None:
            st.error("Problem in computing distribution, check logs for details")
        else:
            dist_df = pd.DataFrame(dist_stats).reset_index()
            dist_df.columns = ["metric", "value"]
            effect_var_final, _, col3 = st.columns(spec=3, gap="medium")
            with col3:
                st.write("")
                st.table(dist_df)
            with effect_var_final:
                st.components.v1.html(
                    make_boxplot(
                        {
                            "min": dist_stats["min"],
                            "q1": dist_stats["25%"],
                            "median": dist_stats["50%"],
                            "q3": dist_stats["75%"],
                            "max": dist_stats["max"],
                        }
                    ),
                    height=500,
                    width=400,
                )

        # section : outliers
        outlier_algos = ["Standard Z Score", "Robust Z Score"]
        st.subheader("Outliers")
        outlier_method_index = (
            1
            if "outlier_method" not in st.session_state
            else outlier_algos.index(st.session_state.outlier_method)
        )

        st.radio(
            key="outlier_method",
            label="Choose an Outlier Detection Algorithm",
            options=outlier_algos,
            index=outlier_method_index,
            horizontal=True,
        )
        if st.session_state.outlier_method == "Robust Z Score":
            result_outliers = detect_outliers(
                inp_df=df, col=st.session_state.col_univariate, method="robust_z_score"
            )
            if result_outliers is None:
                st.error("Problem in detecting outliers, check logs for details")
            else:
                if result_outliers["n_outliers"] == 0:
                    st.write(
                        f"No outliers were found in the column - {st.session_state.col_univariate}"
                    )
                else:
                    outlier_desc = narratives.UNIVARIATE_NUMERIC["outliers_description"].format(
                        **result_outliers
                    )
                    if (
                        result_outliers["outlier_boundary_left"]
                        and result_outliers["outlier_boundary_right"]
                    ):
                        outlier_range_desc = narratives.UNIVARIATE_NUMERIC[
                            "outliers_left_and_right"
                        ].format(**result_outliers)
                    else:
                        if result_outliers["outlier_boundary_left"]:
                            outlier_range_desc = narratives.UNIVARIATE_NUMERIC[
                                "outliers_left"
                            ].format(**result_outliers)
                        else:
                            outlier_range_desc = narratives.UNIVARIATE_NUMERIC[
                                "outliers_right"
                            ].format(**result_outliers)
                    st.markdown(outlier_desc + outlier_range_desc)
        # section : histogram
        st.subheader("Histogram")
        is_remove_outlier_histogram = st.checkbox(
            label="Remove Outliers",
            value=False,
            help="By checking this option, you can remove outliers in data and see a less skewed histogram.",
        )
        if is_remove_outlier_histogram:
            hist_result = get_histogram(
                df.drop(result_outliers["outlier_indexes"], axis=0),
                st.session_state.col_univariate,
            )
        else:
            hist_result = get_histogram(df.iloc[:40000], st.session_state.col_univariate)
        if hist_result is None:
            st.error("Problem in computing histogram, check logs for details.")
        else:
            st.components.v1.html(
                make_histogram1d(
                    data_x_axis=hist_result["edges"],
                    data_y_axis=hist_result["frequencies"],
                ),
                height=470,
                # width=470,
            )
    else:
        if col_summary["Data Type"] == "object":
            MAX_DISPLAY_CATEGORIES = 500
            freq_stats = get_frequency_counts(df.iloc[:40000], st.session_state.col_univariate)[
                0:MAX_DISPLAY_CATEGORIES
            ]
            if freq_stats is None:
                st.error("Problem in computing frequency distribution, check logs for details.")
            else:
                freq_df = pd.DataFrame(freq_stats).reset_index()
                freq_df.columns = ["category", "frequency"]
                tab1, tab2 = st.tabs(["Plot", "Data"])
                with tab2:
                    st.write("Top 20 categories")
                    st.table(freq_df)
                with tab1:
                    st.components.v1.html(
                        make_barplot(
                            data_df=freq_df, x_axis_col="category", y_axis_cols=["frequency"]
                        ),
                        height=500,
                        width=600,
                    )
            # Pareto analysis code begins:
            st.subheader("Pareto Analysis")
            if col_summary["Number of unique values"] > 1:
                if "pareto_col_numeric" not in st.session_state:
                    pareto_numeric_col_idx = 0
                else:
                    if st.session_state.pareto_col_numeric in numerical_cols:
                        pareto_numeric_col_idx = numerical_cols.index(
                            st.session_state.pareto_col_numeric
                        )
                    else:
                        # when dataset is changed in data console, st.session_state.col_univariate\
                        #  has to
                        # be refreshed
                        # else it will hold a variable from previous ds that is not a column in \
                        # current ds
                        pareto_numeric_col_idx = 0
                st.radio(
                    key="pareto_type",
                    label="Do you want to base the pareto on frequency counts or effect variable?",
                    options=["Frequency Counts", "Effect Variable"],
                )

                effect_var_final, col2 = st.columns(spec=2, gap="medium")
                with effect_var_final:
                    st.selectbox(
                        key="pareto_col_numeric",
                        label="Select an effect variable",
                        options=numerical_cols,
                        index=pareto_numeric_col_idx,
                        disabled=False
                        if st.session_state.pareto_type == "Effect Variable"
                        else True,
                    )
                # Data preparation
                if st.session_state.pareto_type == "Effect Variable":
                    pareto_stats = get_cumulative_percent(
                        df.iloc[:40000],
                        st.session_state.col_univariate,
                        st.session_state.pareto_col_numeric,
                        "sum",
                    )[0:MAX_DISPLAY_CATEGORIES]
                else:
                    pareto_stats = get_cumulative_percent(
                        freq_df,
                        "category",
                        "frequency",
                        None,
                    )[0:MAX_DISPLAY_CATEGORIES]
                # checking the data is present or not
                if pareto_stats is None:
                    st.error(
                        "Problem in computing cumulative distribution, check logs for details."
                    )
                else:
                    pareto_stats = pareto_stats.sort_values(
                        st.session_state.pareto_col_numeric
                        if st.session_state.pareto_type == "Effect Variable"
                        else "frequency",
                        ascending=False,
                    )
                    # Creating two tabs (one for plot and other for data table)
                    pareto_stats_sorted = pareto_stats.reset_index(drop=True)
                    tab1, tab2 = st.tabs(["Plot", "Data"])
                    with tab2:
                        st.write("Data table for all categories")
                        st.table(pareto_stats_sorted)
                    with tab1:
                        # Calling pareto plot
                        st.components.v1.html(
                            make_pareto_plot(
                                data_df=pareto_stats,
                                x_axis_col=st.session_state.col_univariate
                                if st.session_state.pareto_type == "Effect Variable"
                                else "category",
                                y_axis_cols=st.session_state.pareto_col_numeric
                                if st.session_state.pareto_type == "Effect Variable"
                                else "frequency",
                            ),
                            height=500,
                            width=600,
                        )
                    # Selecting only 80% contributed categories and making them as list
                    categories_80 = pareto_stats[pareto_stats["cumulative_percent"] <= 80][
                        st.session_state.col_univariate
                        if st.session_state.pareto_type == "Effect Variable"
                        else "category"
                    ].tolist()
                    # Creating a variable to store the column name to print in below st.text_area
                    effect_var_final = (
                        st.session_state.pareto_col_numeric
                        if st.session_state.pareto_type == "Effect Variable"
                        else "frequency"
                    )
                    if len(categories_80) < 5:
                        st.markdown(
                            f"The following are the elements that contribute for 80% of the total "
                            f"{effect_var_final}: {', '.join(categories_80)}",
                            unsafe_allow_html=True,
                        )
                    else:
                        st.markdown(
                            f"The following are the elements that contribute for 80% of the total "
                            f"{effect_var_final}: {', '.join(categories_80[:5])} and "
                            f"<abbr title='{', '.join(categories_80[5:])}'>{len(categories_80[5:])} more.</abbr>",
                            unsafe_allow_html=True,
                        )
            else:
                st.markdown(
                    f"Pareto analysis is not available for this column({col_summary['Column']}), "
                    "since it has only one unique category in it.",
                    unsafe_allow_html=True,
                )

        if col_summary["Data Type"] == "datetime64[ns]":
            dt_result = get_date_column_univariate_insights(
                inp_df=df, col=st.session_state.col_univariate
            )
            if dt_result is None:
                st.error("Problem in computing date insights, check logs for details.")
            st.write(f"min date = {dt_result['min_dt']}")
            st.write(f"max date = {dt_result['max_dt']}")
            st.write(f"frequency = {dt_result['dt_frequency']}")
            st.write(f"Number of missing dates = {dt_result['n_missing_dates']}")
            st.markdown(
                "Missed dates are: "
                "<div style='height: 100px; overflow-y: scroll;'>"
                f"{(', '.join([str(val) for val in dt_result['missed_periods'][1]]))}</div>",
                unsafe_allow_html=True,
            )
            if not dt_result["missed_periods"][1].empty:
                dt_result["dt_freq_counts"].add(
                    pd.Series(
                        [0] * len(dt_result["missed_periods"][1]),
                        index=dt_result["missed_periods"][1].tolist(),
                    ),
                    fill_value=0,
                )
                dt_result["dt_freq_counts"].sort_index(ascending=True, inplace=True)
            plot_df = pd.DataFrame(dt_result["dt_freq_counts"]).reset_index()
            plot_df.columns = [st.session_state.col_univariate, "frequency"]
            plot_df[st.session_state.col_univariate] = plot_df[
                st.session_state.col_univariate
            ].apply(lambda val: str(val))
            st.components.v1.html(
                make_barplot(
                    data_df=plot_df,
                    x_axis_col=st.session_state.col_univariate,
                    y_axis_cols=["frequency"],
                ),
                height=500,
                width=600,
            )
else:
    st.error("You still haven't signed in. Login by going to the User Login page.")
