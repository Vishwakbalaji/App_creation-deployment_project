import os
from datetime import date

import bcrypt
import pandas as pd
import streamlit as st

from app_utils import init_app, leap_logo, make_header, make_topbar_logo_header

init_app()
leap_logo()
make_topbar_logo_header(text="Data Accelerator")
make_header(text="Admin Console")

if st.session_state["logged_in"] is True:
    if st.session_state.is_admin_user is True:
        # 1. Existing user or admin data table
        user_data = pd.read_csv(
            open(os.path.join(st.session_state.user_access_dir, "user_data.csv"))
        )
        st.subheader("User Info:")
        st.table(user_data)

        # 2. Add New user, Delete User, and Modify the details of the existing user
        st.selectbox(
            key="user_detail",
            label="Select your preference: ",
            options=(
                "",
                "Add New User",
                "Update Existing User",
                "Update Existing User passcode only",
                "Delete User",
            ),
        )
        if st.session_state.user_detail == "Add New User":
            with st.form(key="new_user_form"):
                st.title("New User Details: ")
                # Adding details
                today = date.today()
                date = today.strftime("%d/%m/%Y")
                fname = st.text_input("First Name")
                lname = st.text_input("Last Name")
                mobile = st.text_input("Mobile No.", key=int)
                email = st.text_input("Email Id")
                username = st.text_input("Username")
                password = st.text_input("Password", type="password")
                hashed_pass = (bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())).decode()
                user_mode = st.selectbox("What access you prefer?", ("User", "Admin"))

                # Save the New User Details:
                save = st.form_submit_button("Save")
                if save is True:
                    user_data.loc[len(user_data.index)] = [
                        date,
                        fname,
                        lname,
                        mobile,
                        email,
                        username,
                        hashed_pass,
                        user_mode,
                    ]
                    st.table(user_data[user_data["User_Name"] == username])
                    user_data.to_csv(
                        os.path.join(st.session_state.user_access_dir, "user_data.csv"),
                        index=False,
                    )
        elif st.session_state.user_detail == "Update Existing User":
            with st.form(key="update_user_form"):
                st.title("Update User Details: ")

                existing_user_name = st.text_input("Existing Username")
                if existing_user_name != "":
                    exst_user_data = user_data[user_data["User_Name"] == existing_user_name]

                    # First Name
                    fname = st.text_input("First Name", f"{exst_user_data['First_Name'].iloc[0]}")
                    # Last Name
                    lname = st.text_input("Last Name", f"{exst_user_data['Last_Name'].iloc[0]}")
                    # Mobile Number
                    mobile = st.text_input(
                        "Mobile No.", f"{exst_user_data['Mobile'].iloc[0]}", key=int
                    )
                    # Email Id
                    email = st.text_input("Email Id", f"{exst_user_data['Email_Id'].iloc[0]}")
                    # User Name
                    username = st.text_input("Username", f"{exst_user_data['User_Name'].iloc[0]}")
                    # User Mode
                    user_mode = st.selectbox("What access you prefer?", ("User", "Admin"))

                if existing_user_name == "":
                    # Add Update the User Changes
                    st.form_submit_button("Submit")
                else:
                    # Add Update the User Changes
                    update_changes = st.form_submit_button("Update")
                    if update_changes is True:
                        user_data.loc[
                            user_data["User_Name"] == existing_user_name,
                            [
                                "First_Name",
                                "Last_Name",
                                "Mobile",
                                "Email_Id",
                                "User_Name",
                                "User_Previllage",
                            ],
                        ] = (fname, lname, mobile, email, username, user_mode)

                        st.table(user_data[user_data["User_Name"] == existing_user_name])
                        user_data.to_csv(
                            os.path.join(st.session_state.user_access_dir, "user_data.csv"),
                            index=False,
                        )
        elif st.session_state.user_detail == "Update Existing User passcode only":
            with st.form(key="update_user_passcode"):
                st.title("Update User Passcode Details: ")
                existing_user_name = st.text_input("Existing Username")
                if existing_user_name != "":
                    exst_user_data = user_data[user_data["User_Name"] == existing_user_name]
                    # Password
                    password = st.text_input("Password", type="password")
                    hashed_pass = (
                        bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())
                    ).decode()
                    # Creating the update button
                if existing_user_name == "":
                    # Add Update the User Changes
                    st.form_submit_button("Submit")
                else:
                    update_changes = st.form_submit_button("Update")
                    if update_changes is True:
                        user_data.loc[
                            user_data["User_Name"] == existing_user_name, "Hashed_Password"
                        ] = hashed_pass
                        st.table(user_data[user_data["User_Name"] == existing_user_name])
                        user_data.to_csv(
                            os.path.join(st.session_state.user_access_dir, "user_data.csv"),
                            index=False,
                        )
        elif st.session_state.user_detail == "Delete User":
            with st.form(key="delete_user_form"):
                st.title("Delete User Details: ")
                # Filling details
                username = st.text_input("Username")
                email = st.text_input("Email Id")

                # Add Update the User Changes
                delete_user = st.form_submit_button("Delete")
                if delete_user is True:
                    user_data.drop(
                        user_data.index[
                            (
                                (user_data["User_Name"] == username)
                                & (user_data["Email_Id"] == email)
                            )
                        ],
                        axis=0,
                        inplace=True,
                    )
                    st.table(user_data)
                    user_data.to_csv(
                        os.path.join(st.session_state.user_access_dir, "user_data.csv"),
                        index=False,
                    )
    else:
        st.error("This page is not authorized for you to access.")
else:
    st.error("You still haven't signed in. Login by going to the User Login page.")
