import streamlit as st

import narratives as narratives
from app_utils import init_app, leap_logo, make_topbar_logo_header, update_session_state
from plot_utils import make_app_modules_summary_tree

init_app()
leap_logo()
make_topbar_logo_header(text="Data Accelerator")
update_session_state()

if st.session_state["logged_in"] is True:
    st.subheader("What is this app about?")
    st.markdown(
        """
    - AI powered no-code tool that can provide insights on data quality
    - Aids adhoc interactive exploration of data.
    """
    )

    st.subheader("What can this app do?")
    st.markdown(
        """
    - Assess the quality of data 
    - Exploratory data analysis
    """
    )

    st.subheader("Who can use this app?")
    st.markdown(
        """
    - Business users as well as data scientits / analysts who wish to get a quick understanding of the data
    """
    )

    st.subheader("Modules Overview")
    st.components.v1.html(
        make_app_modules_summary_tree(data=narratives.APP_MODULES_TREE), width=650, height=550
    )
else:
    st.error("You still haven't signed in. Login by going to the User Login page.")
