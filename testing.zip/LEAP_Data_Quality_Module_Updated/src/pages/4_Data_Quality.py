"""
This module aims to provide insights on the quality of data like completeness,
duplicates, correlation in missing values.
"""

import os

import pandas as pd
import streamlit as st

from accelerator_utils import (
    calculate_data_quality_score,
    get_column_summary,
    get_data_completeness,
    get_data_df,
    get_duplicate_summary,
    get_missing_correlations,
)
from app_utils import (
    init_app,
    leap_logo,
    make_header,
    make_topbar_logo_header,
    update_session_state,
)
from plot_utils import make_correlation_heatmap, make_gauge_charts

init_app()
leap_logo()
make_topbar_logo_header(text="Data Accelerator")
make_header(text="Data Quality")
update_session_state()

if st.session_state["logged_in"] is True:
    if "dataset" not in st.session_state:
        st.error(
            body="No dataset selected. Please navigate to Data Console tab and select a dataset."
        )
        st.stop()
    else:
        filepath = os.path.join(st.session_state.datasets_dir, st.session_state.dataset)
        df = get_data_df(filepath)
        if df is None:
            st.error(body="Unable to read dataset. Check logs for details.")
            st.stop()

    # Set default values for the sliders and dropdowns
    datetime_columns = list(df.select_dtypes(include="datetime").columns)
    if not datetime_columns:
        datetime_columns = None
    default_completeness_threshold = 50
    default_outlier_threshold = 50
    default_date_range_threshold = 50
    default_uniqueness_threshold = 50
    default_date_columns = datetime_columns
    default_key_columns = None

    # create keys for the sliders and dropdowns
    completeness_threshold_widget_key = "completeness_threshold_widget"
    outlier_threshold_widget_key = "outlier_threshold_widget"
    date_range_threshold_widget_key = "date_range_threshold_widget"
    uniqueness_threshold_widget_key = "uniqueness_threshold_widget"
    date_columns_widget_key = "date_columns_widget"
    key_columns_widget_key = "key_columns_widget"
    completeness_threshold_session_key = "completeness_threshold_session"
    outlier_threshold_session_key = "outlier_threshold_session"
    date_range_threshold_session_key = "date_range_threshold_session"
    uniqueness_threshold_session_key = "uniqueness_threshold_session"
    date_columns_session_key = "date_columns_session"
    key_columns_session_key = "key_columns_session"

    # initialize the slider and dropdown values using the sessionstate object
    session_state = st.session_state
    session_state.setdefault(completeness_threshold_session_key, default_completeness_threshold)
    session_state.setdefault(outlier_threshold_session_key, default_outlier_threshold)
    session_state.setdefault(date_range_threshold_session_key, default_date_range_threshold)
    session_state.setdefault(uniqueness_threshold_session_key, default_uniqueness_threshold)
    session_state.setdefault(date_columns_session_key, default_date_columns)
    session_state.setdefault(key_columns_session_key, default_key_columns)

    def clear_widget_keys():
        widget_keys = [
            completeness_threshold_widget_key,
            outlier_threshold_widget_key,
            date_range_threshold_widget_key,
            uniqueness_threshold_widget_key,
            date_columns_widget_key,
            key_columns_widget_key,
        ]

        for key in widget_keys:
            if key in st.session_state:
                del st.session_state[key]

    def reset_session_state():
        clear_widget_keys()
        st.session_state[completeness_threshold_session_key] = default_completeness_threshold
        st.session_state[outlier_threshold_session_key] = default_outlier_threshold
        st.session_state[date_range_threshold_session_key] = default_date_range_threshold
        st.session_state[uniqueness_threshold_session_key] = default_uniqueness_threshold
        st.session_state[date_columns_session_key] = default_date_columns
        st.session_state[key_columns_session_key] = default_key_columns

    if st.session_state.ds_changed == True:
        reset_session_state()
        st.session_state.ds_changed = False

    def render_graph(
        df,
        completeness_threshold,
        outlier_threshold,
        date_range_threshold,
        uniqueness_threshold,
        key_columns,
        date_columns,
    ):
        (score_df, metrics) = calculate_data_quality_score(
            df,
            completeness_threshold,
            date_range_threshold,
            outlier_threshold,
            uniqueness_threshold,
            date_columns,
            key_columns,
        )
        charts = make_gauge_charts(score_df)
        num_cols = len(charts)
        col_list = st.columns(num_cols)
        for i in range(num_cols):
            with col_list[i]:
                st.components.v1.html(charts[i], height=200)
        return (score_df, metrics)

    # render the initial graph with default values
    session_state.setdefault("refresh_counter", 0)

    def render_graph_and_update_session(df):
        score_df, metrics = render_graph(
            df,
            session_state.get(completeness_threshold_session_key),
            session_state.get(outlier_threshold_session_key),
            session_state.get(date_range_threshold_session_key),
            session_state.get(uniqueness_threshold_session_key),
            session_state.get(date_columns_session_key),
            session_state.get(key_columns_session_key),
        )
        session_state.update_needed = False
        return (score_df, metrics)

    (score_df, metrics) = render_graph_and_update_session(df)

    # create an expander
    expander = st.expander("Customize Plot")
    expander_div = expander.container()
    expander_div.markdown(
        "<style>.custom-expander {{ background-color: rgba(255, 255, 255, 0.7); }}</style>",
        unsafe_allow_html=True,
    )

    # add sliders to the expander
    with expander:
        # add dropdowns to the expander
        st.write("Select columns to plot:")
        date_columns_widget = st.empty()
        if datetime_columns is None:
            st.warning("No datetime columns found.")
        else:
            date_columns = date_columns_widget.multiselect(
                "date columns",
                datetime_columns,
                default=default_date_columns,
                key=date_columns_widget_key,
            )
            # check if all selected columns are of datetime type
            if len(date_columns) == 0:
                session_state[date_columns_session_key] = default_date_columns
            else:
                session_state[date_columns_session_key] = date_columns
        key_columns_widget = st.empty()
        key_columns = key_columns_widget.multiselect(
            "key columns", df.columns, default=default_key_columns, key=key_columns_widget_key
        )
        if len(key_columns) == 0:
            session_state[key_columns_session_key] = default_key_columns
        else:
            session_state[key_columns_session_key] = key_columns

        st.write("Adjust the values of the sliders below:")
        completeness_threshold = st.slider(
            "completeness threshold",
            0,
            100,
            session_state.get(completeness_threshold_session_key),
            key=completeness_threshold_widget_key,
        )
        outlier_threshold = st.slider(
            "outlier threshold",
            0,
            100,
            session_state.get(outlier_threshold_session_key),
            key=outlier_threshold_widget_key,
        )
        date_range_threshold = st.slider(
            "date range threshold",
            0,
            100,
            session_state.get(date_range_threshold_session_key),
            key=date_range_threshold_widget_key,
        )
        uniqueness_threshold = st.slider(
            "uniqueness threshold",
            0,
            100,
            session_state.get(uniqueness_threshold_session_key),
            key=uniqueness_threshold_widget_key,
        )

        # add a button to save the inputs
        if st.button("Save Inputs"):
            # update the slider and dropdown values using the sessionstate object
            session_state[completeness_threshold_session_key] = completeness_threshold
            session_state[outlier_threshold_session_key] = outlier_threshold
            session_state[date_range_threshold_session_key] = date_range_threshold
            session_state[uniqueness_threshold_session_key] = uniqueness_threshold
            session_state["refresh_counter"] = 2
            # session_state["expander_open"] = False

    if session_state["refresh_counter"] > 0:
        # decrement the refresh counter
        session_state["refresh_counter"] -= 1

        # force a refresh of the page
        st.experimental_rerun()

    # section 1.1 : duplicates
    st.subheader("Duplicates")
    dq_sec1_col1, dq_sec1_col2, dq_sec1_col3, dq_sec1_col4 = st.columns(spec=4, gap="large")
    duplicates_summary = get_duplicate_summary(df)
    if duplicates_summary is None:
        st.error("Problem in duplicates analysis. check logs for details...")
    else:
        dq_sec1_col1.metric(label="rows", value=f"{duplicates_summary['Number of rows']}")
        dq_sec1_col2.metric(
            label="duplicate rows",
            value=f"{duplicates_summary['Number of duplicate rows']}",
            delta=f"{round(100 * (duplicates_summary['Number of duplicate rows']/duplicates_summary['Number of rows']), 2)} %",
        )
        dq_sec1_col3.metric(label="columns", value=f"{duplicates_summary['Number of columns']}")
        dq_sec1_col4.metric(
            label="duplicate columns", value=f"{duplicates_summary['Number of duplicate columns']}"
        )
        if duplicates_summary["Duplicate columns"]:
            st.write(
                f"Duplicate columns are : {', '.join(duplicates_summary['Duplicate columns'])}"
            )
            st.write("Duplicate column pairs are below:")
            for item in duplicates_summary["Duplicate column pairs"]:
                st.markdown(f":red[{item[0]}] <--> :red[{item[1]}]")

    # section 1.2 : number of rows vs missing % of cols
    st.subheader("Data completeness")
    data_compl_df = get_data_completeness(df)
    if data_compl_df is None:
        st.error("Problem in computing data completeness. check log for details.")
    else:
        st.table(data_compl_df)

    # section 1.3 : null correlation heatmap
    st.subheader("Nullity Correlation")
    with st.expander("See explanation"):
        st.write(
            """The heatmap is used to identify correlations of the nullity between each of the """
            """different columns. In other words, it can be used to identify if there is a """
            """relationship in the presence of null values between each of the columns. Values close"""
            """ to positive 1 indicate that the presence of null values in one column is correlated"""
            """ with the presence of null values in another column.Values close to negative"""
            """ 1 indicate that the presence of null values in one column is anti-correlated """
            """with the presence of null values in another column. In other words, when null values """
            """are present in one column, there are data values present in the other column, """
            """and vice versa.Values close to 0, indicate there is little to no relationship """
            """between the presence of null values in one column compared to another."""
        )
    df_missing_corr = get_missing_correlations(df)
    if df_missing_corr is None:
        st.error("Problem in computing correlations of missing values. check logs for details.")
    else:
        if df_missing_corr["corr_scaled"].max() < 80:
            st.info(
                """there is little to no relationship between the presence of null"""
                """ values in one column compared to another."""
            )
        else:
            heatmap_categories = df_missing_corr["col1"].unique().tolist()
            st.components.v1.html(
                make_correlation_heatmap(
                    data_x_axis=heatmap_categories,
                    data_y_axis=heatmap_categories,
                    plot_data=df_missing_corr[["col1", "col2", "corr_scaled"]].values.tolist(),
                ),
                scrolling=False,
                height=700,
                width=900,
            )

    # section 2 : column wise Data Quality metrics in a paginated table
    st.subheader("Column-wise data quality metrics")

    if "page_number" not in st.session_state:
        st.session_state.page_number = 0

    N_COLS_PER_PAGE = 10
    last_page = len(df.columns) / N_COLS_PER_PAGE

    col_prev, col_next = st.columns(spec=2, gap="large")
    if col_next.button("Next"):
        if st.session_state.page_number + 1 > last_page:
            st.session_state.page_number = 0
        else:
            st.session_state.page_number += 1
    if col_prev.button("Previous"):
        if st.session_state.page_number - 1 < 0:
            st.session_state.page_number = last_page
        else:
            st.session_state.page_number -= 1

    start_idx = st.session_state.page_number * N_COLS_PER_PAGE
    end_idx = (st.session_state.page_number + 1) * N_COLS_PER_PAGE
    result = [
        get_column_summary(df, colname) for colname in df.columns.tolist()[start_idx:end_idx]
    ]
    # if errors in column summary, result will have None, remove None in display
    result = [res for res in result if res]
    if result:
        try:
            result = pd.DataFrame(result).merge(metrics, on="Column", how="left")
            result.fillna("Not Applicable", inplace=True)
            st.table(result)
        except NameError:
            st.table(pd.DataFrame(result))
    else:
        st.warning("Unable to retrieve column summary, check logs for details.")
else:
    st.error("You still haven't signed in. Login by going to the User Login page.")
