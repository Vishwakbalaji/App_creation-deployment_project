import os

import pandas as pd
import streamlit as st

from accelerator_utils import (
    get_advanced_data_cleaning,
    get_basic_data_cleaning,
    get_data_df,
    push_data_to_dbfs,
)
from app_utils import (
    init_app,
    leap_logo,
    make_header,
    make_topbar_logo_header,
    update_dataset_related_states,
    update_session_state,
)

init_app()
leap_logo()
make_topbar_logo_header(text="Data Accelerator")
make_header(text="Data Cleaning")
update_session_state()

if st.session_state["logged_in"] is True:
    if "dataset" not in st.session_state:
        update_dataset_related_states()
        st.error(
            body="No dataset selected. Please navigate to Data Console tab and select a dataset."
        )
        st.stop()
    else:
        filepath = os.path.join(st.session_state.datasets_dir, st.session_state.dataset)
        df = get_data_df(filepath)
        if df is None:
            st.error(body="Unable to read dataset. Check logs for details.")
            st.stop()

        # 1. Creating a selection box to choose which type of data cleaning needed!!
        st.selectbox(
            key="data_cleaning_type_options",
            label="Choose your preference:",
            options=(
                "",
                "Generic cleaning",
                "Demand forecasting specific cleaning",
                "Both Generic and Demand forecasting specific cleaning",
            ),
        )

        # Processs1
        if st.session_state.data_cleaning_type_options == "Generic cleaning":
            Process1 = st.radio(
                "Please follow the below procedures:",
                (
                    "Step1: Generic cleaning",
                    "Step2: Push Cleaned Data to DBFS",
                ),
            )
            if Process1 == "Step1: Generic cleaning":
                if (
                    st.session_state.selected_database_name_from_user is not None
                    and st.session_state.selected_table_name_from_user is not None
                ):
                    filepath = os.path.join(
                        st.session_state.datasets_dir,
                        "silver_"
                        + st.session_state.selected_table_name_from_user.split("_")[1]
                        + ".csv",
                    )
                else:
                    filepath = os.path.join(
                        st.session_state.datasets_dir, "cleaned_" + st.session_state.dataset
                    )
                if not os.path.exists(filepath):
                    filepath = os.path.join(
                        st.session_state.datasets_dir, st.session_state.dataset
                    )
                df = pd.read_csv(filepath)
                get_basic_data_cleaning(df, "No")

            elif Process1 == "Step2: Push Cleaned Data to DBFS":
                push_data_to_dbfs(st.session_state.new_updated_dataset)

        # Processs2
        elif st.session_state.data_cleaning_type_options == "Demand forecasting specific cleaning":
            Process2 = st.radio(
                "Please follow the below procedures:",
                (
                    "Step1: Demand forecasting specific cleaning",
                    "Step2: Push Cleaned Data to DBFS",
                ),
            )
            if Process2 == "Step1: Demand forecasting specific cleaning":
                if (
                    st.session_state.selected_database_name_from_user is not None
                    and st.session_state.selected_table_name_from_user is not None
                ):
                    filepath = os.path.join(
                        st.session_state.datasets_dir,
                        "silver_"
                        + st.session_state.selected_table_name_from_user.split("_")[1]
                        + ".csv",
                    )
                else:
                    filepath = os.path.join(
                        st.session_state.datasets_dir,
                        "advanced_cleaning_" + st.session_state.dataset,
                    )
                if not os.path.exists(filepath):
                    filepath = os.path.join(
                        st.session_state.datasets_dir, st.session_state.dataset
                    )
                df = pd.read_csv(filepath)
                get_advanced_data_cleaning(df, "No")

            elif Process2 == "Step2: Push Cleaned Data to DBFS":
                push_data_to_dbfs(st.session_state.new_updated_dataset)

        # Processs3
        elif (
            st.session_state.data_cleaning_type_options
            == "Both Generic and Demand forecasting specific cleaning"
        ):
            Process3 = st.radio(
                "Please follow the below procedures:",
                (
                    "Step1: Generic cleaning",
                    "Step2: Demand forecasting specific cleaning",
                    "Step3: Push Cleaned Data to DBFS",
                ),
            )

            if Process3 == "Step1: Generic cleaning":
                if (
                    st.session_state.selected_database_name_from_user is not None
                    and st.session_state.selected_table_name_from_user is not None
                ):
                    filepath = os.path.join(
                        st.session_state.datasets_dir,
                        "basic_cleaning_"
                        + st.session_state.selected_table_name_from_user.split("_")[1]
                        + ".csv",
                    )
                    st.session_state.process1_step1_data = filepath
                else:
                    filepath = os.path.join(
                        st.session_state.datasets_dir,
                        "basic_cleaning_" + st.session_state.dataset,
                    )
                    st.session_state.process1_step1_data = filepath
                if not os.path.exists(filepath):
                    filepath = os.path.join(
                        st.session_state.datasets_dir, st.session_state.dataset
                    )
                df = pd.read_csv(filepath)
                get_basic_data_cleaning(df, "Yes")

            elif Process3 == "Step2: Demand forecasting specific cleaning":
                if (
                    st.session_state.selected_database_name_from_user is not None
                    and st.session_state.selected_table_name_from_user is not None
                ):
                    filepath = os.path.join(
                        st.session_state.datasets_dir,
                        "silver_"
                        + st.session_state.selected_table_name_from_user.split("_")[1]
                        + ".csv",
                    )
                else:
                    filepath = os.path.join(
                        st.session_state.datasets_dir,
                        "advanced_cleaning_" + st.session_state.dataset,
                    )
                if not os.path.exists(filepath):
                    filepath = os.path.join(
                        st.session_state.datasets_dir,
                        st.session_state.process1_step1_data,
                    )
                df = pd.read_csv(filepath)
                get_advanced_data_cleaning(df, "Yes")

            elif Process3 == "Step3: Push Cleaned Data to DBFS":
                push_data_to_dbfs(st.session_state.new_updated_dataset)
else:
    st.error("You still haven't signed in. Login by going to the User Login page.")
