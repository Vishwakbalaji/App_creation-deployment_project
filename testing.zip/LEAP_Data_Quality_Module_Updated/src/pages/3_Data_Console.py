"""
Functionalities embedded in this code : provide facility to upload datasets,
selection of dataset for insights on various other pages,
show high level file statistics,
show a preview of data with 10 rows.
"""
import datetime
import os

import numpy as np
import pandas as pd
import streamlit as st
from databricks import sql as dbsql  # pip install databricks-sql-connector

from accelerator_utils import get_dataset_summary, get_histogram
from app_utils import (
    init_app,
    leap_logo,
    make_header,
    make_topbar_logo_header,
    update_dataset_related_states,
    update_session_state,
)
from plot_utils import make_histogram1d

init_app()
leap_logo()
make_topbar_logo_header(text="Data Accelerator")
make_header(text="Data Console")
update_session_state()

# Every time we vist this page the push path gets none. so that push path will be created new all time
st.session_state.dbfs_push_path = None

if st.session_state["logged_in"] is True:
    # Warning the user to select only the csv format files.
    st.subheader(f"Hello {st.session_state.user_name}!!")
    st.markdown("""When you are selecting the table/dataset, choose only the 'CSV' format.""")
    if "dataset" not in st.session_state:
        update_dataset_related_states()

    # Arranging the selecting options in column wise
    col1, col2, col3 = st.columns([3, 6, 4])  # Input Data1 for delta table
    cols1, cols2 = st.columns([9, 4])  # Input Data2 for delta table
    column1, column2 = st.columns([6, 7])  # Output Data for delta table and upload data

    with col1:
        st.write("")
        # Creating a ratio button to choose which one of the data reading method needed
        st.selectbox(
            key="data_reading_options",
            label="Choose your preference:",
            options=(
                "",
                "Databricks Delta Lake",
                "Uploading Directly",
            ),
        )
    if st.session_state.data_reading_options == "Databricks Delta Lake":
        # Configuration variables - from your keyvault and Databricks
        databricks_pat = "dapiaa7b7b8e92adbce1f90be9b44b1649a5-3"
        server_hostname = "adb-2192895227016004.4.azuredatabricks.net"
        http_path = "sql/protocolv1/o/2192895227016004/0831-152137-lmrqu9u7"

        # Define the connection to the SQL endpoint
        connection = dbsql.connect(
            server_hostname=str(server_hostname),
            http_path=str(http_path),
            access_token=str(databricks_pat),
        )
        cursor = connection.cursor()

        with col2:
            st.write("")
            # Getting the Database names for the dropdown selection
            cursor.execute("SHOW DATABASES")
            db_names = [""] + [row.databaseName for row in cursor.fetchall()]
            database_name = st.selectbox("Which database would you prefer?", tuple(db_names))
            if database_name != "":
                with col3:
                    st.write("")
                    # Getting the Table names from the selected database shown in this dropdown
                    cursor.execute(f"SHOW TABLES IN {str(database_name)}")
                    tb_names = [""] + [row[1] for row in cursor.fetchall()]
                    table_name = st.selectbox("Which table would you prefer?", tuple(tb_names))
                    if table_name != "":
                        # with col1:
                        #     execute = st.button("Execute")

                        if table_name is not None:  # and execute is True:
                            # checking the table name has bronze_ or not
                            if "bronze_" in table_name:
                                st.session_state.selected_table_name_from_user = table_name
                            else:
                                st.session_state.selected_table_name_from_user = None

                            # checking the databse has mappings table or not
                            if "mappings" in tb_names:
                                st.session_state.selected_database_name_from_user = database_name
                            else:
                                st.session_state.selected_database_name_from_user = None

                            # Below we are preparing the data for the metrics
                            cursor.execute(
                                str(f"SELECT COUNT(*) FROM {database_name}.{table_name}")
                            )
                            row_count = cursor.fetchall()[0][0]
                            cursor.execute(f"SHOW COLUMNS IN {database_name}.{table_name}")
                            column_count = len([row.col_name for row in cursor.fetchall()])

                            # Below we are preparing the data for the preview
                            cursor.execute(f"SELECT * FROM {database_name}.{table_name}")
                            data = cursor.fetchall()
                            cursor.execute(f"SHOW COLUMNS IN {database_name}.{table_name}")
                            columns = [column[0] for column in cursor.fetchall()]

                            df = pd.DataFrame(data=data, columns=columns)  # reading the data
                            st.session_state.dataset = f"{table_name}.csv"

                            # If date column is present in the dataframe, then it will be converted
                            # into datetime64 (Hardcoded):
                            for date_col in df.columns.tolist():
                                if "Date" in date_col or "date" in date_col:
                                    df[date_col] = df[date_col].astype("str")
                                    df[date_col] = pd.to_datetime(df[date_col])

                            file_path = os.path.join(
                                st.session_state.datasets_dir, st.session_state.dataset
                            )
                            df.to_csv(
                                file_path,
                                index=False,
                                header=True,
                            )  # saving the data
                            # file_size:
                            file_size_bytes = os.path.getsize(file_path)
                            # file_stats for the last modified data!!
                            file_stats = os.stat(file_path)

                            # 1. Data Summary
                            with column1:
                                st.subheader("Data Summary")
                                st.table(
                                    pd.DataFrame(
                                        data=[
                                            {"Metric": "Database name", "Value": database_name},
                                            {"Metric": "Table name", "Value": table_name},
                                            {"Metric": "Number of rows", "Value": row_count},
                                            {"Metric": "Number of columns", "Value": column_count},
                                            {
                                                "Metric": "File size",
                                                "Value": f"{file_size_bytes/(1<<20):,.0f} MB\
                                              / {file_size_bytes/(1<<30):,.0f} GB",
                                            },
                                            {
                                                "Metric": "Last Modified time",
                                                "Value": datetime.datetime.fromtimestamp(
                                                    file_stats.st_mtime
                                                ),
                                            },
                                        ]
                                    )
                                )

                            # Data Preview
                            with column2:
                                st.subheader("Data Preview")
                                st.table(df.head())

                            with column1:
                                st.warning("Navigate to the Data Quality..")

    elif st.session_state.data_reading_options == "Uploading Directly":
        st.session_state.selected_table_name_from_user = None
        st.session_state.selected_database_name_from_user = None
        with col2:
            st.write("")
            st.selectbox(
                key="data_picking_options",
                label="Choose from the below options(except blank):",
                options=(
                    "",
                    "Direct Upload Options",
                    "Direct Selecting Options",
                ),
            )
        with cols1:
            if st.session_state.data_picking_options == "Direct Upload Options":
                st.session_state.selected_table_name_from_user = None
                st.session_state.selected_database_name_from_user = None
                st.write("")
                uploaded_file = st.file_uploader(
                    "Please upload your file:",
                )
                if uploaded_file is not None:
                    df = pd.read_csv(uploaded_file)
                    # If date column is present in the dataframe, then it will be converted
                    # into datetime64 (Hardcoded):
                    for date_col in df.columns.tolist():
                        if "Date" in date_col or "date" in date_col:
                            df[date_col] = df[date_col].astype("str")
                            df[date_col] = pd.to_datetime(df[date_col])

                    df.to_csv(
                        os.path.join(st.session_state.datasets_dir, uploaded_file.name),
                        index=False,
                        header=True,
                    )
                    st.write("file uploaded...")
                    st.session_state.dataset = uploaded_file.name

                    with column1:
                        st.write("")
                        # section 2 : file stats
                        filepath = os.path.join(
                            st.session_state.datasets_dir, st.session_state.dataset
                        )
                        st.subheader("Dataset Summary")
                        ds_summary = get_dataset_summary(dataset_path=filepath)
                        if ds_summary is not None:
                            st.table(ds_summary)
                        else:
                            st.error("Problem in reading the dataset, check logs for details...")
                            st.stop()

                    with column2:
                        st.write("")
                        # section 3 : preview - sample 10 rows
                        st.subheader("Data Preview")
                        st.table(pd.read_csv(filepath, nrows=4))

                    with column1:
                        st.warning("Navigate to the Data Quality..")

            elif st.session_state.data_picking_options == "Direct Selecting Options":
                st.session_state.selected_table_name_from_user = None
                st.session_state.selected_database_name_from_user = None
                datasets_list = [
                    f for f in os.listdir(st.session_state.datasets_dir) if f.endswith(".csv")
                ]
                if not datasets_list:
                    st.error(
                        "There is no dataset available for analysis. Consider uploading a dataset \
                            via above file uploader."
                    )
                    st.stop()
                else:
                    selected_ds_index = (
                        0
                        if "dataset" not in st.session_state
                        else datasets_list.index(st.session_state.dataset)
                    )

                    # Selection options are coded here---
                    st.write("")
                    comp_ds = st.selectbox(
                        key="dataset",
                        label="Please select you files:",
                        options=datasets_list,
                        index=selected_ds_index,
                        help="dataset selected in this section will be used throughout the app for\
                              analysis",
                        on_change=update_dataset_related_states,
                    )

                    with column1:
                        st.write("")
                        # section 2 : file stats
                        filepath = os.path.join(
                            st.session_state.datasets_dir, st.session_state.dataset
                        )
                        df = pd.read_csv(filepath)
                        # If date column is present in the dataframe, then it will be converted
                        # into datetime64 (Hardcoded):
                        for date_col in df.columns.tolist():
                            if "Date" in date_col or "date" in date_col:
                                df[date_col] = df[date_col].astype("str")
                                df[date_col] = pd.to_datetime(df[date_col])
                        df.to_csv(
                            filepath,
                            index=False,
                            header=True,
                        )
                        st.subheader("Dataset Summary")
                        ds_summary = get_dataset_summary(dataset_path=filepath)
                        if ds_summary is not None:
                            st.table(ds_summary)
                        else:
                            st.error("Problem in reading the dataset, check logs for details...")
                            st.stop()

                    with column2:
                        st.write("")
                        # section 3 : preview - sample 10 rows
                        st.subheader("Data Preview")
                        st.table(pd.read_csv(filepath, nrows=4))

                    with column1:
                        st.warning("Navigate to the Data Quality..")
else:
    st.error("You still haven't signed in. Login by going to the User Login page.")
