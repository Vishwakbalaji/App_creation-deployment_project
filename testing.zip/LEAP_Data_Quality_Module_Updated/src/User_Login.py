import os

import bcrypt
import pandas as pd
import streamlit as st

from app_utils import init_app, leap_logo, make_topbar_logo_header

init_app()
leap_logo()
make_topbar_logo_header(text="Data Accelerator")

# Load user data from CSV file
user_data = pd.read_csv(open(os.path.join(st.session_state.user_access_dir, "user_data.csv")))

# --- USER AUTHENTICATION ---
st.session_state["logged_in"] = None
# Create Streamlit form
with st.form(key="login_form"):
    st.title("Login")
    # Add login and password fields
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    # Add login button
    login = st.form_submit_button("Login")
    # Login Verification
    if login is True:
        indv_user_data = user_data[user_data["User_Name"] == username]
        if (username == indv_user_data["User_Name"].iloc[0]) and (
            bcrypt.checkpw(
                password.encode("utf-8"),
                (indv_user_data["Hashed_Password"].iloc[0]).encode("utf-8"),
            )
            is True
        ):
            st.session_state.user_name = username
            st.session_state["logged_in"] = True
            if indv_user_data["User_Previllage"].iloc[0] == "Admin":
                st.session_state.is_admin_user = True
            else:
                st.session_state.is_admin_user = False
        else:
            st.session_state["logged_in"] = False
            st.error("Invalid username or password")

if st.session_state["logged_in"] is True:
    st.warning("Login successful")
elif st.session_state["logged_in"] is False:
    st.error("Username/password is incorrect")
elif st.session_state["logged_in"] is None:
    st.warning("Please enter your username and password")
