"""
Utility functions relevant to the streamlit framework / app.
"""
import base64
import os

import streamlit as st
from loguru import logger


def init_app():
    """Initializes app"""
    if "initialized" in st.session_state:
        logger.debug("returning since already initialized ....")
        return
    st.session_state.datasets_dir = os.path.join(os.getcwd(), "data/datasets")
    st.session_state.static_dir = os.path.abspath("./static/")
    st.session_state.user_access_dir = os.path.abspath("./user_access/")
    st.session_state.initialized = True
    st.session_state.updated_dataset = None
    st.session_state.dbfs_push_path = None
    logger.debug(f"st.session_state.datasets_dir = {st.session_state.datasets_dir}")
    logger.debug("app initialized ....")


def make_header(text: str):
    """
    Creates a header using with the value of parameter text.
    """
    # st.write(f'<p style="font-size:2vw;text-align:center">{text}</p>', unsafe_allow_html=True)
    st.title(text)


def leap_logo():
    """Create logo and footer text for sidebar"""
    with open(os.path.join(st.session_state.static_dir, "leap_logo.png"), "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read()).decode("utf-8")
    url = f"data:image/png;base64,{encoded_string}"

    st.markdown(
        f"""
        <style>
            [data-testid="stSidebarNav"] {{
                background-image: url({url});
                background-repeat: no-repeat;
                background-size: 228px;
                padding-top: 100px;
                background-position: 10px 10px;
            }}
            [data-testid="stSidebarNav"]::before {{
                content: "Data Quality Framework by Innover Digital Inc.";
                margin-left: 20px;
                margin-top: 20px;
                margin-bottom: 5px;
                font-size: 10px;
                font-weight: bold;
                position: relative;
                top: 20px; /* adjust this value to reduce/increase the space */
                bottom: 10px
            }}
        </style>
        """,
        unsafe_allow_html=True,
    )


def make_topbar_logo_header(text):
    """Inserting two logo's and main header"""
    # Use st.markdown to apply CSS styling to the image, text and shows like a top bar.
    st.markdown(
        """
        <style>
        body, html, .streamlit-container {
            margin: 0;
            padding: 0;
        }
        .css-18ni7ap {
        background: none;
        }
        /* Remove any additional padding or margin */
        body, #root {
            height: 100vh;
            margin: 0;
            padding: 0;
            opacity: 1;
        }
        /* Custom top bar styles */
        .topbar {
            position: fixed;
            top: 7px;
            left: 0;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #008080;
            color: white;
            height: 100px;
            font-size: 53px;
            font-weight: bold;
            opacity: 1;
            z-index: 9999; /* set a high z-index value */
        }
        /* Centered text */
        .center-text {
            flex-grow: 1; /* Allow the text to take up remaining space */
            text-align: center;
            margin-left: 145px;
        }
        /* Remove any additional padding or margin */
        .streamlit-container {
            padding: 0 !important;
            margin: 0 !important;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    # This markdown is calling the above markdown and inserting the images and text in a
    # particular format.
    st.markdown(
        f"""
        <div class="topbar">
            <div class="center-text">{text}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def update_session_state():
    """
    when key is associated with a ui component, its state is not maintained between page
    navigation.
    hence this workaround to update the session state during page visits.
    """
    for key, val in st.session_state.items():
        if key in st.session_state:
            st.session_state[key] = val


def update_dataset_related_states():
    """
    reset session variables when dataset changes or on first load
    """
    st.session_state.bivariate_type_idx = -1
    st.session_state.ds_changed = True
