"""
Utility functions that provide plot functionalities.
Methods do not use streamlit components.
Pyecharts and Plotly are commonly used libraries here but not restricted to these.
"""
from typing import Dict, List, Tuple

import pandas as pd
import plotly.graph_objects as go
from pyecharts import options as opts
from pyecharts.charts import Bar, Grid, HeatMap, Line, Liquid, Scatter, Tree
from pyecharts.commons.utils import JsCode


def make_correlation_heatmap(
    data_x_axis: List[str], data_y_axis: List[str], plot_data: List[Tuple]
) -> str:
    """
    Generate a heatmap given x-axis and y-axis categories, along with data of cells.
    plot_data looks like this [['category1','category2',35],['category4','category5',98],..]
    """
    return (
        HeatMap()
        .add_xaxis(data_x_axis)
        .add_yaxis("correlation", data_y_axis, plot_data, label_opts=opts.LabelOpts(is_show=False))
        .set_global_opts(
            xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(rotate=90)),
            visualmap_opts=opts.VisualMapOpts(),
        )
        .render_embed()
    )


def make_heatmap(data_df: pd.DataFrame, col_x: str, col_y: str, col_value: str) -> str:
    """
    Generate a heatmap given x-axis and y-axis column names with data in col_value column.
    """
    max_val = data_df[col_value].max()
    min_val = data_df[col_value].min()
    min_val = 0 if min_val == max_val else min_val

    return (
        HeatMap(init_opts=opts.InitOpts(width="600px", height="500px"))
        .add_xaxis(data_df[col_x].unique().tolist())
        .add_yaxis(
            series_name="",
            yaxis_data=data_df[col_y].unique().tolist(),
            value=data_df[[col_x, col_y, col_value]].values.tolist(),
            label_opts=opts.LabelOpts(is_show=False),
        )
        .set_global_opts(
            xaxis_opts=opts.AxisOpts(
                name=col_x,
                name_location="middle",
                name_gap=10,
                axislabel_opts=opts.LabelOpts(rotate=90),
            ),
            yaxis_opts=opts.AxisOpts(
                name=col_y,
                name_location="end",
            ),
            visualmap_opts=opts.VisualMapOpts(
                min_=float(min_val),
                max_=float(max_val),
                is_calculable=True,
                orient="horizontal",
                pos_top="0.005%",
                pos_right="20%",
                range_text=[f"max {col_value}", f"min {col_value}"],
            ),
            datazoom_opts=[
                opts.DataZoomOpts(orient="vertical", is_show=True, range_start=0, range_end=100),
                opts.DataZoomOpts(
                    orient="horizontal", is_show=True, range_start=0, range_end=100, pos_bottom=10
                ),
            ],
        )
        .render_embed()
    )


def make_boxplot(distribution_values: dict) -> str:
    """
    Generate a box plot using pre-computed data.
    input param must be a dictionary with precomputed quartiles
    input param must include these keys : min, q1, median, q3, max
    """
    fig = go.Figure()
    fig.add_trace(go.Box())
    fig.update_traces(
        q1=[distribution_values["q1"]],
        median=[distribution_values["median"]],
        q3=[distribution_values["q3"]],
        lowerfence=[distribution_values["min"]],
        upperfence=[distribution_values["max"]],
    )
    fig.update_layout(
        margin=dict(l=20, r=20, t=0, b=0),
    )
    return fig.to_html()


def make_barplot(data_df: pd.DataFrame, x_axis_col: str, y_axis_cols: List[str]) -> str:
    """
    Generates bar plot with categories on x-axis and values on y-axis.
    Performance is to be taken care by providing limited sized inputs in the parameters.
    Datazoom slider takes care of scalable representation to an extent.
    However its recommended to not include more than 1000 categories.
    """
    bar_plot = Bar(init_opts=opts.InitOpts(width="500px", height="420px")).add_xaxis(
        data_df[x_axis_col].values.tolist()
    )
    for col in y_axis_cols:
        bar_plot.add_yaxis(
            series_name=col,
            y_axis=data_df[col].values.tolist(),
            label_opts=opts.LabelOpts(is_show=False),
        )

    bar_plot.set_global_opts(
        xaxis_opts=opts.AxisOpts(
            name=x_axis_col, name_location="end", axislabel_opts=opts.LabelOpts(rotate=90)
        ),
        datazoom_opts=opts.DataZoomOpts(range_start=0, range_end=100),
    )

    return (
        Grid(init_opts=opts.InitOpts(width="600px", height="450px"))
        .add(bar_plot, grid_opts=opts.GridOpts(pos_left=20, pos_right=None, is_contain_label=True))
        .render_embed()
    )


def make_histogram1d(data_x_axis: List[float], data_y_axis: List[int]) -> str:
    """
    Generates histogram. this is very similar to make_barplot method except that
    the category gaps are 0 in x axis and label rotations are disabled.
    data_x_axis are supposed to be values of bin edges
    data_y_axis must be frequency counts
    """
    hist_plot = (
        Bar()
        .add_xaxis(data_x_axis)
        .add_yaxis(
            "frequency", data_y_axis, category_gap=0, label_opts=opts.LabelOpts(is_show=False)
        )
        .set_global_opts(
            datazoom_opts=opts.DataZoomOpts(range_start=0, range_end=100),
        )
    )

    return (
        Grid(init_opts=opts.InitOpts(width="500px", height="450px"))
        .add(
            hist_plot, grid_opts=opts.GridOpts(pos_left=50, pos_right=None, is_contain_label=True)
        )
        .render_embed()
    )


def make_scatterplot(
    data_df: pd.DataFrame, col_x: str, col_y: str, col_color: str = None, col_size: str = None
) -> str:
    """
    Generates scatter plot between data_x_axis and data_y_axis.
    Additionally when data_color is provided, series with one color for each category is created
    also points can be sized by the value in param data_size
    """
    # create x axis
    scatter_plot = Scatter(
        init_opts=opts.InitOpts(width="500px", height="500px", renderer="canvas")
    ).add_xaxis(data_df[col_x].astype("float").values.tolist())

    # create y axis
    if col_color:
        if col_size:
            # x * y * color * size
            for category in data_df[col_color].unique():
                data_y = data_df.apply(
                    lambda row: [float(row[col_y]), float(row[col_size])]
                    if row[col_color] == category
                    else [None, None],
                    axis=1,
                ).tolist()
                scatter_plot.add_yaxis(
                    series_name=str(category),
                    y_axis=data_y,
                    label_opts=opts.LabelOpts(is_show=False),
                )
        else:
            # x * y * color
            for category in data_df[col_color].unique():
                data_y = data_df.apply(
                    lambda row: float(row[col_y]) if row[col_color] == category else None, axis=1
                ).tolist()
                scatter_plot.add_yaxis(
                    series_name=str(category),
                    y_axis=data_y,
                    label_opts=opts.LabelOpts(is_show=False),
                )
    else:
        if col_size:
            # x * y * size
            y_data = data_df[[col_y, col_size]].astype("float").values.tolist()
            series_name = f"{col_x} vs {col_y}, sized by {col_size}"
        else:
            # simple x * y
            y_data = data_df[col_y].astype("float").values.tolist()
            series_name = f"{col_x} vs {col_y}"
        scatter_plot.add_yaxis(
            series_name=series_name,
            y_axis=y_data,
            label_opts=opts.LabelOpts(is_show=False),
        )

    # create global options
    # visualmapopts is the one extra if size variable is chosen
    yaxis_opts = opts.AxisOpts(
        name=col_y,
        name_location="middle",
        name_gap=40,
        name_rotate=90,
        boundary_gap=False,
        type_="value",
        is_scale=True,
        axistick_opts=opts.AxisTickOpts(is_show=True),
        splitline_opts=opts.SplitLineOpts(is_show=True),
    )
    xaxis_opts = opts.AxisOpts(
        name=col_x,
        name_location="middle",
        name_gap=20,
        boundary_gap=False,
        type_="value",
        is_scale=True,
        axistick_opts=opts.AxisTickOpts(is_show=True),
    )
    legend_opts = opts.LegendOpts(type_="scroll", orient="horizontal")
    datazoom_opts = [
        opts.DataZoomOpts(
            orient="horizontal", is_show=True, range_start=0, range_end=100, pos_bottom=10
        ),
        opts.DataZoomOpts(orient="vertical", is_show=True, range_start=0, range_end=100),
    ]
    if col_size:
        visualmap_opts = opts.VisualMapOpts(
            type_="size",
            max_=float(data_df[col_size].max()),
            min_=float(data_df[col_size].min()),
            dimension=2,
            orient="horizontal",
            pos_top="5%",
            pos_left="center",
            item_height=140,
            item_width=9,
            textstyle_opts=opts.TextStyleOpts(font_size=10),
            range_text=[f"max {col_size}", f"min {col_size}"],
        )
        scatter_plot.set_global_opts(
            legend_opts=legend_opts,
            datazoom_opts=datazoom_opts,
            visualmap_opts=visualmap_opts,
            yaxis_opts=yaxis_opts,
            xaxis_opts=xaxis_opts,
        )

    else:
        scatter_plot.set_global_opts(
            legend_opts=legend_opts,
            datazoom_opts=datazoom_opts,
            yaxis_opts=yaxis_opts,
            xaxis_opts=xaxis_opts,
        )

    return scatter_plot.render_embed()
    # adding scatterplot with visualmapopts to a grid gives error
    # error :  visualmap_opts=opts.VisualMapOpts(type_="size", max_=20, min_=1)
    # hence not using grid for scatter plot
    # grid = Grid(init_opts=opts.InitOpts(width="500px", height="500px"))
    # grid = grid.add(
    #     scatter_plot,
    #     grid_opts=opts.GridOpts(pos_left="5%"),
    # ).render_embed()
    # return grid


def make_date_vs_numeric_lineplot(
    data_df: pd.DataFrame, x_axis_col: str, y_axis_cols: List[str], y_axis_name: str = ""
) -> str:
    """
    Generates line plot with categories on x-axis and values on y-axis.
    the x axis type is set to time. so input param data_df is assumed to contain date type col
    """
    data_x = data_df[x_axis_col].dt.date.values.tolist()

    line_plot = Line().add_xaxis(data_x)
    for col in y_axis_cols:
        line_plot.add_yaxis(
            series_name=col,
            y_axis=list(map(lambda val: round(val, 2), data_df[col].values.tolist())),
            symbol_size=3,
            label_opts=opts.LabelOpts(is_show=False),
            linestyle_opts=opts.LineStyleOpts(width=2, type_="solid"),
        )
    line_plot.set_global_opts(
        yaxis_opts=opts.AxisOpts(
            name=y_axis_name,
            name_location="end",
            name_gap=10,
            type_="value",
            is_scale=True,
            axistick_opts=opts.AxisTickOpts(is_show=True),
            splitline_opts=opts.SplitLineOpts(is_show=True),
        ),
        xaxis_opts=opts.AxisOpts(
            name=x_axis_col,
            name_location="middle",
            name_gap=30,
            type_="time",
            boundary_gap=False,
            is_scale=True,
            axistick_opts=opts.AxisTickOpts(is_show=True),
        ),
        datazoom_opts=[
            opts.DataZoomOpts(range_start=0, range_end=100),
        ],
    )

    return (
        Grid(init_opts=opts.InitOpts(width="600px", height="450px"))
        .add(
            line_plot, grid_opts=opts.GridOpts(pos_left=20, pos_right=None, is_contain_label=True)
        )
        .render_embed()
    )


def make_app_modules_summary_tree(data: Dict, title: str = "") -> str:
    tree_plot = (
        Tree()
        .add("", [data], layout="radial")
        .set_global_opts(title_opts=opts.TitleOpts(title=title))
    )
    return (
        Grid(init_opts=opts.InitOpts(width="600px", height="500px"))
        .add(tree_plot, grid_opts=opts.GridOpts(is_contain_label=True))
        .render_embed()
    )


def make_pareto_plot(data_df: pd.DataFrame, x_axis_col: str, y_axis_cols: str) -> str:
    """
    Generates overlaped bar & line plot with categories on x-axis and numeric on
    primary y-axis and cummulative percent on secondary y-axis.
    Performance is to be taken care by providing limited sized inputs in the parameters.
    Datazoom slider takes care of scalable representation to an extent.
    However its recommended to not include more than 1000 categories.
    """
    # Bar plot
    Y = []
    for i, j, k in zip(data_df["cumulative_percent"], data_df[y_axis_cols], data_df[x_axis_col]):
        if i <= 80:
            Y.append(
                opts.BarItem(
                    name=k,
                    value=j,
                    itemstyle_opts=opts.ItemStyleOpts(color="#FF8C00"),
                )
            )
        else:
            Y.append(
                opts.BarItem(
                    name=k,
                    value=j,
                    itemstyle_opts=opts.ItemStyleOpts(color="#0000FF"),
                )
            )
    bar_plot = Bar(init_opts=opts.InitOpts(width="500px", height="420px")).add_xaxis(
        data_df[x_axis_col].values.tolist()
    )
    bar = (
        bar_plot.add_xaxis(data_df[x_axis_col].values.tolist())
        .add_yaxis(y_axis_cols, Y)
        .extend_axis(
            yaxis=opts.AxisOpts(
                name="cumulative_percent",
                name_location="end",
                axislabel_opts=opts.LabelOpts(formatter="{value} %"),
                interval=5,
                name_gap=20,
                axistick_opts=opts.AxisTickOpts(is_show=True),
                splitline_opts=opts.SplitLineOpts(is_show=True),
                axispointer_opts=opts.AxisPointerOpts(is_show=False),
                name_textstyle_opts=opts.TextStyleOpts(
                    font_size=15, font_weight="bold", font_family="Dubai"
                ),
            )
        )
        .set_series_opts(label_opts=opts.LabelOpts(is_show=False), z_level=0)
        .set_global_opts(
            # title_opts=opts.TitleOpts(title="Pareto Graphs"),
            xaxis_opts=opts.AxisOpts(
                name=x_axis_col,
                name_location="middle",
                axislabel_opts=opts.LabelOpts(rotate=90),
                name_gap=100,
                axistick_opts=opts.AxisTickOpts(is_show=True),
                splitline_opts=opts.SplitLineOpts(is_show=True),
                axispointer_opts=opts.AxisPointerOpts(is_show=False),
                name_textstyle_opts=opts.TextStyleOpts(
                    font_size=15, font_weight="bold", font_family="Dubai"
                ),
            ),
            yaxis_opts=opts.AxisOpts(
                name=y_axis_cols,
                name_location="end",
                axislabel_opts=opts.LabelOpts(formatter="{value}"),
                name_gap=20,
                axistick_opts=opts.AxisTickOpts(is_show=True),
                splitline_opts=opts.SplitLineOpts(is_show=True),
                axispointer_opts=opts.AxisPointerOpts(is_show=False),
                name_textstyle_opts=opts.TextStyleOpts(
                    font_size=15, font_weight="bold", font_family="Dubai"
                ),
            ),
            datazoom_opts=[
                opts.DataZoomOpts(orient="vertical", is_show=True, range_start=0, range_end=100),
                opts.DataZoomOpts(orient="horizontal", is_show=True, range_start=0, range_end=100),
            ],
        )
    )
    # Line plot
    line = (
        Line()
        .add_xaxis(data_df[x_axis_col].values.tolist())
        .add_yaxis(
            "cumulative_percent",
            data_df["cumulative_percent"].values.tolist(),
            yaxis_index=1,
            z_level=1,  # Set z_level to a higher value to bring the line to the front
        )
        .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
    )
    bar.overlap(line)  # Overlapping

    return (
        Grid(init_opts=opts.InitOpts(width="600px", height="500px"))
        .add(
            bar,
            grid_opts=opts.GridOpts(pos_left=15, is_contain_label=True),
            is_control_axis_index=True,
        )
        .render_embed()
    )


def make_gauge_charts(
    df: pd.DataFrame,
    columns: List[str] = None,
    width: str = "140px",
    height: str = "220px",
    threshold: int = 70,
    colors: Dict[str, List[str]] = None,
) -> List[str]:
    """
    Create and render liquid gauge charts for specified columns in a DataFrame.

    :param df: The input DataFrame containing the data for the charts.
    :param columns: A list of column names to use for creating the gauge charts. If not provided, all columns in the DataFrame will be used.
    :param width: The width of the liquid gauge chart (default: "140px").
    :param height: The height of the liquid gauge chart (default: "220px").
    :param threshold: The threshold value to determine the low score range (default: 70).
    :param colors: A dictionary of colors for different scenarios (default, na, low_score). If not provided, default colors will be used.
    :return: A list of rendered liquid gauge charts in HTML format.
    """
    if colors is None:
        colors = {
            "default": ["#FFA07A", "#FFA500"],
            "na": ["#D3D3D3", "#D3D3D3"],
            "low_score": ["#FF4500", "#FF0000"],
        }

    if columns is None:
        columns = df.columns

    data: List[Tuple[str, Union[int, None]]] = []
    for col in columns:
        score = df[col].iloc[0]
        if score is not None:
            score = round(score, 0)
        data.append((col, score))

    charts: List[str] = []
    for i in range(len(data)):
        score = data[i][1]
        color = colors["default"]
        if score is None:
            label_text = "NA"
            color = colors["na"]
        elif score < threshold:
            label_text = str(int(score))
            color = colors["low_score"]
        else:
            label_text = str(int(score))

        liquid = Liquid(init_opts=opts.InitOpts(width=width, height=height))
        liquid.set_global_opts(
            title_opts=opts.TitleOpts(
                title=data[i][0],
                pos_left="center",
                pos_top="top",
                title_textstyle_opts=opts.TextStyleOpts(font_size=10),
            ),
            legend_opts=opts.LegendOpts(is_show=False),
            tooltip_opts=opts.TooltipOpts(is_show=False),
            toolbox_opts=opts.ToolboxOpts(is_show=False),
        )
        liquid.add(
            "score",
            [data[i][1] / 100 if data[i][1] is not None else None],
            label_opts=opts.LabelOpts(
                font_size=15,
                formatter=JsCode(
                    f"""function (param) {{
                        return '{label_text}';
                    }}"""
                ),
            ),
            color=color,
        )
        charts.append(liquid.render_embed())

    return charts
